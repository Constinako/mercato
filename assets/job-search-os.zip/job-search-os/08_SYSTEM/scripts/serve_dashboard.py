#!/usr/bin/env python3
"""
Tiny dashboard server with a live Refresh button.

Serves 06_OUTPUTS/reports as static files, plus one extra route:
  GET /regenerate  -> re-runs generate_dashboard.py (to-date), then redirects
                      back to the dashboard so the Refresh button shows fresh data.

Run:  python3 08_SYSTEM/scripts/serve_dashboard.py [port]   (default 8789)
"""
import os, sys, subprocess, http.server, functools

HERE = os.path.dirname(os.path.abspath(__file__))
REPORTS = os.path.abspath(os.path.join(HERE, "..", "..", "06_OUTPUTS", "reports"))
GEN = os.path.join(HERE, "generate_dashboard.py")
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8789

class Handler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith("/regenerate"):
            try:
                subprocess.run([sys.executable, GEN, "to-date"], check=True,
                               capture_output=True, timeout=60)
            except Exception as e:
                self.send_error(500, f"regenerate failed: {e}")
                return
            self.send_response(302)
            self.send_header("Location", "/job_search_dashboard_latest.html")
            self.end_headers()
            return
        return super().do_GET()

if __name__ == "__main__":
    os.chdir(REPORTS)
    handler = functools.partial(Handler, directory=REPORTS)
    print(f"Dashboard server on http://localhost:{PORT}/job_search_dashboard_latest.html")
    http.server.HTTPServer(("", PORT), handler).serve_forever()
