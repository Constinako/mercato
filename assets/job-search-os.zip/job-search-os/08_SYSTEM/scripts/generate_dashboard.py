#!/usr/bin/env python3
"""
Job search dashboard + report generator.

Single source of truth for the /report and /dashboard commands and the
auto-update hook. Reads the applications tracker, computes the funnel and
conversion metrics, and writes a self-contained HTML dashboard plus a
markdown report.

Usage:
    python3 generate_dashboard.py [to-date|weekly|monthly] [YYYY-MM-DD or YYYY-MM]

Defaults to to-date. Always (re)writes the stable "latest" files so the
/dashboard command and the hook have a fixed target, plus a dated copy.

Pure stdlib, no dependencies.
"""
import csv, sys, os, datetime
from collections import defaultdict, Counter

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
TRACKER = os.path.join(ROOT, "03_TRACKERS", "applications_tracker.csv")
ASSESSMENTS = os.path.join(ROOT, "03_TRACKERS", "role_assessments.csv")
RECRUITER = os.path.join(ROOT, "03_TRACKERS", "recruiter_tracker.csv")
OUTDIR = os.path.join(ROOT, "06_OUTPUTS", "reports")

def load_recruiters():
    if not os.path.exists(RECRUITER): return []
    with open(RECRUITER, newline="") as f:
        rows = list(csv.DictReader(f))
    return rows

def count_assessments():
    if not os.path.exists(ASSESSMENTS): return 0
    with open(ASSESSMENTS, newline="") as f:
        return max(len(list(csv.reader(f))) - 1, 0)

# ---------- parsing ----------
def load():
    if not os.path.exists(TRACKER):
        return []
    with open(TRACKER, newline="") as f:
        rows = list(csv.reader(f))
    recs = []
    for r in rows[1:]:
        def g(i): return r[i].strip() if i < len(r) else ""
        recs.append(dict(date=g(0), company=g(1), role=g(2), cat=g(3), wt=g(4),
                         loc=g(5), stage=g(6), rounds=g(7), ats=g(8), mf=g(9), ip=g(10),
                         sal=g(11), rec=g(12)))
    return recs

def canon(s):
    s = s.lower()
    if ("rejected" in s or "no response" in s) and ("interview" in s or "round" in s): return "RejPostIntv"
    if "round 2" in s: return "Round 2"
    if "interview" in s or "awaiting" in s: return "Interview"
    if "rejected" in s: return "Rejected"
    if s == "no response": return "No Response"
    if "interested" in s: return "PassInterested"
    if "pass" in s or "did not apply" in s or "not pursued" in s: return "Passed"
    if "withdraw" in s: return "Withdrawn"
    if "recruiter intro" in s: return "RecruiterIntro"
    if "recruiter inbound" in s: return "RecruiterInbound"
    if "recruiter outreach" in s: return "RecruiterOutreach"
    if s == "applied" or "hold" in s or "warm" in s: return "Pending"
    return "Pending"

def lane(c):
    # Lanes are simply the Role Category the user records, cleaned up. This keeps
    # the dashboard adaptable to any field. Edit your categories in the trackers;
    # the lanes follow automatically.
    c = (c or "").strip()
    if not c:
        return "Uncategorized"
    return c.replace("-", " / ").replace("_", " ").title()

def reached_interview(c): return c in ("Interview", "Round 2", "RejPostIntv")
def active_interview(c): return c in ("Interview", "Round 2")

# ---------- metrics ----------
def compute(recs):
    for d in recs:
        d["c"] = canon(d["stage"]); d["l"] = lane(d["cat"])
    recruiter = [d for d in recs if d["c"] in ("RecruiterIntro", "RecruiterInbound", "RecruiterOutreach")]
    applied = [d for d in recs if d["c"] not in ("Passed", "Withdrawn", "PassInterested", "RecruiterIntro", "RecruiterInbound", "RecruiterOutreach")]
    N = len(applied)
    intv = [d for d in applied if reached_interview(d["c"])]          # ever reached an interview (milestone)
    def _rounds(d):
        if d.get("rounds","").strip().isdigit(): return int(d["rounds"])
        s = d["stage"].lower()
        return 2 if ("round 2" in s or "round2" in s) else 1
    total_rounds = sum(_rounds(d) for d in intv)
    intv_active = [d for d in applied if active_interview(d["c"])]    # still in process
    rejpost = [d for d in applied if d["c"] == "RejPostIntv"]         # interviewed then rejected
    rej_no_intv = [d for d in applied if d["c"] == "Rejected"]        # rejected without interview
    rej = rej_no_intv + rejpost                                       # total rejections
    noresp = [d for d in applied if d["c"] == "No Response"]
    pend = [d for d in applied if d["c"] == "Pending"]
    responded = rej_no_intv + intv                                   # got a real decision
    recs_r = load_recruiters()
    r_in_convo = [r for r in recs_r if r.get("Status","").lower() == "in conversation"]
    r_pending = [r for r in recs_r if r.get("Status","").lower() == "pending reply"]
    r_new = [r for r in recs_r if r.get("Status","").lower() == "new"]
    r_no_fit = [r for r in recs_r if r.get("Status","").lower() == "no fit"]
    r_stale = [r for r in recs_r if r.get("Status","").lower() == "stale"]
    r_role_opened = [r for r in recs_r if r.get("Status","").lower() == "role opened"]
    r_applied = [r for r in recs_r if r.get("Status","").lower() == "applied"]
    r_interviewed = [r for r in recs_r if r.get("Status","").lower() == "interviewed"]
    r_warm = [r for r in recs_r if r.get("Type","").lower() == "warm intro"]
    r_inbound = [r for r in recs_r if r.get("Type","").lower() == "inbound"]
    r_outbound = [r for r in recs_r if r.get("Type","").lower() == "outreach"]
    m = dict(total=len(recs), N=N, intv=intv, intv_active=intv_active, total_rounds=total_rounds, rejpost=rejpost,
             rej_no_intv=rej_no_intv, rej=rej, noresp=noresp, pend=pend,
             responded=responded, applied=applied,
             passed=len([d for d in recs if d["c"] == "Passed"]),
             pass_interested=len([d for d in recs if d["c"] == "PassInterested"]),
             withdrawn=len([d for d in recs if d["c"] == "Withdrawn"]),
             recs_r=recs_r, r_in_convo=r_in_convo, r_pending=r_pending,
             r_new=r_new, r_no_fit=r_no_fit, r_stale=r_stale,
             r_role_opened=r_role_opened, r_applied=r_applied, r_interviewed=r_interviewed,
             r_warm=r_warm, r_inbound=r_inbound, r_outbound=r_outbound,
             assessed=count_assessments())
    # lanes
    lanes = defaultdict(list)
    for d in applied: lanes[d["l"]].append(d)
    m["lanes"] = []
    for ln, items in sorted(lanes.items(), key=lambda x: -len(x[1])):
        iv = len([d for d in items if reached_interview(d["c"])])
        m["lanes"].append(dict(lane=ln, apps=len(items), intv=iv,
                               rate=iv/len(items)*100 if items else 0,
                               pending=len([d for d in items if d["c"] == "Pending"])))
    # effort by month
    bym = Counter(d["date"][:7] for d in applied if d["date"])
    m["months"] = sorted(bym.items())
    # interviews detail
    m["intv_detail"] = sorted(intv, key=lambda d: d["date"])
    return m

def pct(a, b): return (a / b * 100) if b else 0

# ---------- markdown ----------
def render_md(m, period, today):
    L = []
    L.append(f"# Job Search Report — {period}\n")
    L.append(f"**Generated:** {today}  ")
    L.append(f"**Source:** 03_TRACKERS/applications_tracker.csv ({m['total']} records)\n")
    L.append("## Headline KPIs\n")
    L.append("| Metric | Value |")
    L.append("|---|---|")
    L.append(f"| Applications sent | {m['N']} |")
    L.append(f"| Interviews reached | {len(m['intv'])} |")
    L.append(f"| Interview rate (of applied) | {pct(len(m['intv']),m['N']):.1f}% |")
    L.append(f"| Response rate | {pct(len(m['responded']),m['N']):.1f}% |")
    L.append(f"| Interview rate (of responders) | {pct(len(m['intv']),len(m['responded'])):.1f}% |")
    L.append(f"| Rejected | {pct(len(m['rej']),m['N']):.1f}% ({len(m['rej'])}) |")
    L.append(f"| Ghost / no-response | {pct(len(m['noresp']),m['N']):.1f}% ({len(m['noresp'])}) |")
    L.append(f"| Active / pending | {len(m['pend'])} |\n")
    L.append("## Conversion by Lane\n")
    L.append("| Lane | Apps | Interviews | Rate | Pending |")
    L.append("|---|---|---|---|---|")
    for r in m["lanes"]:
        L.append(f"| {r['lane']} | {r['apps']} | {r['intv']} | {r['rate']:.1f}% | {r['pending']} |")
    L.append("\n## Effort by Month\n")
    L.append("| Month | Applications |")
    L.append("|---|---|")
    for mo, n in m["months"]:
        L.append(f"| {mo} | {n} |")
    L.append(f"| **Total** | **{sum(n for _,n in m['months'])}** |\n")
    L.append("## Interviews\n")
    for d in m["intv_detail"]:
        L.append(f"- {d['date']} — {d['company']} ({d['role']}) [{d['l']}]")
    return "\n".join(L) + "\n"

# ---------- html ----------
MONTHS = ["", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
def mlabel(mo):
    y, m = mo.split("-")
    return f"{MONTHS[int(m)]} {y}"

def bar_svg(months):
    if not months: return "<div class='note'>No data.</div>"
    mx = max(n for _, n in months) or 1
    W, H, pad, bw = 560, 190, 30, 52
    gap = (W - pad*2 - bw*len(months)) / max(len(months)-1, 1) if len(months) > 1 else 0
    bars = []
    for i, (mo, n) in enumerate(months):
        x = pad + i*(bw+gap)
        bh = (n/mx)*(H-52)
        y = H-32-bh
        bars.append(f'<rect x="{x:.0f}" y="{y:.0f}" width="{bw}" height="{bh:.0f}" rx="5" fill="var(--accent)"/>')
        bars.append(f'<text x="{x+bw/2:.0f}" y="{y-6:.0f}" text-anchor="middle" fill="var(--ink)" font-size="13" font-weight="700">{n}</text>')
        bars.append(f'<text x="{x+bw/2:.0f}" y="{H-10}" text-anchor="middle" fill="var(--muted)" font-size="11">{mlabel(mo)}</text>')
    return f'<svg viewBox="0 0 {W} {H}" width="100%" style="max-width:{W}px">{"".join(bars)}</svg>'

def funnel_html(m):
    pend = len(m["pend"]); ghost = len(m["noresp"])
    rej_ni = len(m["rej_no_intv"]); intv = len(m["intv"])
    active = len(m["intv_active"]); rejpost = len(m["rejpost"])
    stages = [
        (0, "Applied", m["N"], "var(--accent)"),
        (0, "No response", pend + ghost, "#6b7280"),
        (1, "Pending (no reply yet)", pend, "#8a93a3"),
        (1, "Ghosted", ghost, "var(--bad)"),
        (0, "Got a response", rej_ni + intv, "#4a7fd0"),
        (1, "Rejected (no interview)", rej_ni, "var(--bad)"),
        (1, "Interviewed", intv, "var(--good)"),
        (2, "Still active", active, "var(--good)"),
        (2, "Rejected after interview", rejpost, "var(--bad)"),
        (0, "Offer", 0, "var(--ai)"),
    ]
    base = m["N"] or 1
    rows = []
    for indent, label, n, col in stages:
        w = max(pct(n, base), 1.5)
        lbl = ("&#8627; " if indent else "") + label
        rows.append(
            f'<div class="funnel-row" style="padding-left:{24*indent}px"><div class="funnel-label" style="width:{160-0}px">{lbl}</div>'
            f'<div class="funnel-bar" style="background:{col};width:{w:.0f}%">{n} &middot; {pct(n,base):.1f}%</div></div>')
    return "".join(rows)

def narrative(m):
    """Data-driven What's working / not / watch / decisions."""
    lanes = [r for r in m["lanes"] if r["apps"] >= 3]
    best = max(lanes, key=lambda r: r["rate"], default=None)
    worst = min(lanes, key=lambda r: r["rate"], default=None)
    ghost = pct(len(m["noresp"]), m["N"])
    pend_total = len(m["pend"])
    top_pend = max(m["lanes"], key=lambda r: r["pending"], default=None)
    working, notworking, watch, decisions = [], [], [], []
    if best and best["intv"] > 0:
        working.append(f"<b>{best['lane']}</b> is the top-converting lane ({best['rate']:.1f}%, {best['intv']}/{best['apps']}).")
    if m["months"]:
        working.append(f"Steady effort: {sum(n for _,n in m['months'])} applications across {len(m['months'])} months.")
    if ghost >= 30:
        notworking.append(f"<b>{ghost:.0f}% ghost rate</b>: a lot of applications never get a reply. Likely too many thin-fit submissions.")
    if worst and worst is not best and worst["apps"] >= 3:
        notworking.append(f"{worst['lane']} is lowest-yield so far ({worst['rate']:.1f}%, {worst['apps']} apps).")
    if top_pend and top_pend["pending"]:
        watch.append(f"<b>{top_pend['pending']} {top_pend['lane']}</b> applications still open: these will move the numbers as they resolve.")
    if pend_total:
        watch.append(f"{pend_total} applications pending overall ({pct(pend_total,m['N']):.0f}% of applied).")
    # concrete, computed decisions (fully data-driven, no hard-coded targets)
    if worst and worst is not best and worst["apps"] >= 5 and worst["rate"] < 5:
        decisions.append(f"<b>Reconsider the {worst['lane']} lane</b>: {worst['apps']} applications at {worst['rate']:.1f}% interview rate is low yield. Either sharpen the fit or redirect the effort.")
    if best and best["intv"] > 0:
        decisions.append(f"<b>Lean into {best['lane']}</b>: your strongest lane at {best['rate']:.1f}%, with {best['pending']} applications still open.")
    active_names = ", ".join(d["company"] for d in m["intv_active"])
    if active_names:
        decisions.append(f"<b>Convert what's in hand first</b>: prep your active interviews ({active_names}) before sending more applications.")
    if ghost >= 30:
        decisions.append("<b>Raise the bar before applying</b>: assess roles first and skip weak-fit ones. A higher ghost rate usually means volume over fit.")
    if not decisions:
        decisions.append("Keep applying and capturing outcomes. Once ~15 to 20 applications resolve, this section fills with concrete, data-backed calls.")
    def ul(items): return "<ul>" + "".join(f"<li>{x}</li>" for x in items) + "</ul>"
    return f"""<div class="group-header">Synthesis</div>
<h2>What this says</h2>
<div class="card grid two">
<div><div class="pill" style="background:rgba(72,199,142,.15);color:var(--good)">WORKING</div>{ul(working)}</div>
<div><div class="pill" style="background:rgba(255,107,107,.15);color:var(--bad)">NOT WORKING</div>{ul(notworking) if notworking else '<div class="note">Nothing flagged this period.</div>'}</div>
</div>
<div class="card" style="margin-top:14px"><div class="pill" style="background:rgba(179,136,255,.15);color:var(--ai)">WATCH</div>{ul(watch)}</div>
<div class="card" style="margin-top:14px"><div class="pill" style="background:rgba(106,166,255,.15);color:var(--accent)">DECISIONS</div>{ul(decisions)}</div>"""

def loc_bucket(s):
    # Generic: use the location string as written, lightly normalized. The pie
    # below shows the top locations dynamically, so this adapts to any geography.
    s = (s or "").strip()
    if not s or s.lower() == "unknown":
        return "Unknown"
    return s

def mode_bucket(s):
    s = s.lower()
    if not s or s == "unknown": return "Unknown"
    if "hybrid" in s or "flexible" in s: return "Hybrid"
    if "on-site" in s or "in-office" in s or "office" in s or "on site" in s: return "On-site"
    if "remote" in s: return "Remote"
    return "Unknown"

import math
def pie_svg(data):
    """data: list of (label, count, color)."""
    total = sum(c for _, c, _ in data) or 1
    cx, cy, r = 90, 90, 80
    ang = -math.pi/2
    paths = []
    for label, c, col in data:
        if c == 0: continue
        frac = c/total; a2 = ang + frac*2*math.pi
        x1, y1 = cx+r*math.cos(ang), cy+r*math.sin(ang)
        x2, y2 = cx+r*math.cos(a2), cy+r*math.sin(a2)
        large = 1 if frac > .5 else 0
        if frac >= 0.999:
            paths.append(f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{col}"/>')
        else:
            paths.append(f'<path d="M{cx},{cy} L{x1:.1f},{y1:.1f} A{r},{r} 0 {large},1 {x2:.1f},{y2:.1f} Z" fill="{col}"/>')
        ang = a2
    legend = "".join(
        f'<div style="display:flex;align-items:center;gap:8px;margin:5px 0;font-size:13px">'
        f'<span style="width:12px;height:12px;border-radius:3px;background:{col};display:inline-block"></span>'
        f'<span>{label}</span><span style="color:var(--muted);margin-left:auto">{c} ({c/total*100:.0f}%)</span></div>'
        for label, c, col in data if c)
    return (f'<div style="display:flex;gap:28px;align-items:center;flex-wrap:wrap">'
            f'<svg viewBox="0 0 180 180" width="180" height="180">{"".join(paths)}</svg>'
            f'<div style="flex:1;min-width:200px">{legend}</div></div>')

def render_caveated(m):
    applied = m["applied"]
    def num(x):
        try: return float(x)
        except: return None
    # two location pies: by location (top values, dynamic) and by work mode
    lc = Counter(loc_bucket(d["loc"]) for d in applied)
    palette = ["var(--accent)", "var(--ai)", "var(--good)", "var(--warn)", "#4a90d9", "#e07b7b"]
    known = [(k, n) for k, n in lc.most_common() if k != "Unknown"]
    top = known[:6]
    rest = sum(n for _, n in known[6:])
    country_data = [(k, n, palette[i % len(palette)]) for i, (k, n) in enumerate(top)]
    if rest:
        country_data.append(("Other", rest, "#6b7280"))
    if lc.get("Unknown", 0):
        country_data.append(("Unknown", lc["Unknown"], "#4a5160"))
    mc = Counter(mode_bucket(d["wt"]) for d in applied)
    mcols = {"On-site": "var(--accent)", "Hybrid": "var(--good)", "Remote": "var(--ai)", "Unknown": "#4a5160"}
    mode_data = [(k, mc.get(k, 0), mcols[k]) for k in ["On-site", "Hybrid", "Remote", "Unknown"]]
    unknown_loc = lc.get("Unknown", 0)
    known_loc = len(applied) - unknown_loc
    loc_caveat = f' <span style="font-size:12px;font-weight:400;color:var(--warn)">&#9888; only {known_loc} of {len(applied)} have location data</span>' if unknown_loc > len(applied) * 0.3 else ""
    # ATS bands
    bands = {"<50": [], "50-59": [], "60-69": [], "70+": []}
    for d in applied:
        a = num(d["ats"])
        if a is None: continue
        k = "<50" if a < 50 else "50-59" if a < 60 else "60-69" if a < 70 else "70+"
        bands[k].append(d)
    ats_n = sum(len(v) for v in bands.values())
    ats_caveat = f' <span style="font-size:12px;font-weight:400;color:var(--warn)">&#9888; only {ats_n} of {len(applied)} have a numeric ATS score</span>' if ats_n < len(applied) * 0.5 else ""
    ats_band_colors = {"<50": "var(--bad)", "50-59": "var(--muted)", "60-69": "var(--accent)", "70+": "var(--good)"}
    ats_rows = "".join(
        f'<tr><td style="color:{ats_band_colors.get(k, "var(--muted)")}">{k}</td><td class="num">{len(v)}</td><td class="num">{len([d for d in v if reached_interview(d["c"])])}</td>'
        f'<td class="num" style="color:{ats_band_colors.get(k,"var(--muted)")}">{pct(len([d for d in v if reached_interview(d["c"])]),len(v)):.0f}%</td></tr>'
        for k, v in bands.items() if v)
    # recommendation
    byr = defaultdict(list)
    for d in applied:
        if d["rec"] in ("Apply", "Maybe Apply", "Do Not Apply"): byr[d["rec"]].append(d)
    rec_n = sum(len(v) for v in byr.values())
    rec_caveat = f' <span style="font-size:12px;font-weight:400;color:var(--warn)">&#9888; only {rec_n} of {len(applied)} have a recorded recommendation</span>' if rec_n < len(applied) * 0.5 else ""
    rec_colors = {"Apply": "var(--good)", "Maybe Apply": "var(--warn)", "Do Not Apply": "var(--bad)"}
    rec_rows = "".join(
        f'<tr><td style="color:{rec_colors.get(k, "var(--muted)")}">{k}</td><td class="num">{len(byr[k])}</td><td class="num">{len([d for d in byr[k] if reached_interview(d["c"])])}</td>'
        f'<td class="num" style="color:{rec_colors.get(k,"var(--muted)")}">{pct(len([d for d in byr[k] if reached_interview(d["c"])]),len(byr[k])):.0f}%</td></tr>'
        for k in ["Apply", "Maybe Apply", "Do Not Apply"] if byr.get(k))
    return f"""
<div class="group-header">Scoring Validation</div>
<h2>ATS score band vs interview conversion{ats_caveat}</h2>
<div class="card">
  <table><tr><th>ATS band</th><th class="num">Apps</th><th class="num">Interviews</th><th class="num">Interview rate</th></tr>{ats_rows if ats_rows else '<tr><td colspan="4" style="color:var(--muted);text-align:center;padding:14px">No numeric ATS scores recorded yet.</td></tr>'}</table>
  <div class="note">Does a higher ATS score actually predict an interview? This answers it. Reliable once ~20 applications have a numeric ATS score.</div>
</div>

<h2>System recommendation vs interview conversion{rec_caveat}</h2>
<div class="card">
  <table><tr><th>Recommendation</th><th class="num">Apps</th><th class="num">Interviews</th><th class="num">Interview rate</th></tr>{rec_rows if rec_rows else '<tr><td colspan="4" style="color:var(--muted);text-align:center;padding:14px">No recommendations recorded yet.</td></tr>'}</table>
  <div class="note">Is the system's scoring calibrated? "Apply" calls should convert at a higher rate than "Maybe Apply." Meaningful once ~30 scored applications have resolved.</div>
</div>

<div class="group-header">Context</div>
<h2>Location spread{loc_caveat}</h2>
<div class="card">
  <div class="grid two">
    <div><div class="note" style="margin:0 0 8px;font-weight:600;color:var(--ink)">By location</div>{pie_svg(country_data)}</div>
    <div><div class="note" style="margin:0 0 8px;font-weight:600;color:var(--ink)">By work mode</div>{pie_svg(mode_data)}</div>
  </div>
  <div class="note">Distribution across all {len(applied)} applications. "Unknown" entries mean the field wasn't captured on that row.</div>
</div>"""

INSIGHTS_FILE = os.path.join(ROOT, "09_INSIGHTS", "insights_synthesis.md")
import re
def render_insights():
    """Read curated qualitative insights and render the CMF hypothesis + insights cards."""
    empty_note = '<div style="color:var(--muted);font-size:13px;font-style:italic;padding:4px 0">Sharpens over time as patterns emerge.</div>'
    if not os.path.exists(INSIGHTS_FILE):
        return (f'<h2>Candidate&ndash;market fit hypothesis</h2>'
                f'<div class="card" style="border-left:3px solid var(--ai)">{empty_note}</div>'
                f'<h2>Career tracks &amp; skills to build</h2>'
                f'<div class="card" style="border-left:3px solid var(--good)">{empty_note}</div>'
                f'<h2>Insights gathered</h2>'
                f'<div class="card" style="border-left:3px solid var(--warn)">{empty_note}<div class="note">Hand-curated patterns from interviews, rejections, and captured learnings. Edit in <code>09_INSIGHTS/insights_synthesis.md</code>.</div></div>')
    txt = open(INSIGHTS_FILE).read()
    def section(name):
        m2 = re.search(rf"##\s*{re.escape(name)}\s*\n(.*?)(?=\n##\s|\Z)", txt, re.S)
        return m2.group(1).strip() if m2 else ""
    cmf = section("Candidate-Market Fit Hypothesis")
    cmf = " ".join(l.strip() for l in cmf.splitlines() if l.strip() and not l.strip().startswith("<!--"))
    insights = [l.strip()[2:].strip() for l in section("Insights").splitlines() if l.strip().startswith("- ")]
    tracks = [l.strip()[2:].strip() for l in section("Tracks & Skills").splitlines() if l.strip().startswith("- ")]
    def md_b(s):
        return re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", s)
    out = (f'<h2>Candidate&ndash;market fit hypothesis</h2>'
           f'<div class="card" style="border-left:3px solid var(--ai)">'
           f'<div style="font-size:14.5px;line-height:1.65">{md_b(cmf) if cmf else empty_note}</div></div>')
    items = "".join(f"<li style='margin:8px 0'>{md_b(t)}</li>" for t in tracks)
    out += (f'<h2>Career tracks &amp; skills to build</h2>'
            f'<div class="card" style="border-left:3px solid var(--good)">'
            f'{"<ul style=\"margin:0 0 0 18px\">" + items + "</ul>" if tracks else empty_note}'
            f'<div class="note">Where to aim now, the adjacent track to grow into, and the gap-closing skills in priority order.</div></div>')
    items = "".join(f"<li style='margin:7px 0'>{md_b(i)}</li>" for i in insights)
    out += (f'<h2>Insights gathered</h2>'
            f'<div class="card" style="border-left:3px solid var(--warn)">'
            f'{"<ul style=\"margin:0 0 0 18px\">" + items + "</ul>" if insights else empty_note}'
            f'<div class="note">Hand-curated patterns from interviews, rejections, and captured learnings. Edit in <code>09_INSIGHTS/insights_synthesis.md</code>.</div></div>')
    return out

def render_html(m, period, today):
    gen_at = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    intv_rate = pct(len(m['intv']), m['N'])
    resp_rate = pct(len(m['responded']), m['N'])
    resp_intv = pct(len(m['intv']), len(m['responded']))
    rej_rate = pct(len(m['rej']), m['N'])
    ghost = pct(len(m['noresp']), m['N'])
    months = m["months"]; total_eff = sum(n for _, n in months)
    # rank lanes by interview rate; colour text by rank (top = green, 2nd = blue, rest = muted)
    ranked = sorted(m["lanes"], key=lambda r: (-r["rate"], -r["apps"]))
    rank_color = {}
    for i, r in enumerate(ranked):
        rank_color[r["lane"]] = "var(--good)" if (i == 0 and r["rate"] > 0) else \
                                "var(--accent)" if (i == 1 and r["rate"] > 0) else "var(--muted)"
    lane_rows = []
    for r in ranked:
        c = rank_color[r["lane"]]
        lane_rows.append(
            f'<tr style="color:{c}"><td><b>{r["lane"]}</b></td><td class="num">{r["apps"]}</td>'
            f'<td class="num">{r["intv"]}</td><td class="num"><b>{r["rate"]:.1f}%</b></td>'
            f'<td class="num">{r["pending"]}</td></tr>')
    pend_rows = "".join(
        f'<tr><td><span class="{"ai" if r["lane"].startswith("AI") else ""}">{r["lane"]}</span></td>'
        f'<td class="num">{r["pending"]}</td></tr>'
        for r in sorted(m["lanes"], key=lambda x: -x["pending"]) if r["pending"])
    def istatus(d):
        if d["c"] == "RejPostIntv":
            label = d["stage"].strip() if d["stage"].strip() else "Rejected after interview"
            return f'<span style="color:var(--bad)">{label}</span>'
        return '<span style="color:var(--good)">Active</span>'
    def rounds(d):
        if d.get("rounds", "").strip().isdigit():
            return int(d["rounds"])
        s = d["stage"].lower()
        return 2 if ("round 2" in s or "round2" in s) else 1
    intv_rows = "".join(
        f'<tr><td>{d["date"][5:]}</td><td>{d["company"]}</td>'
        f'<td><span class="tag">{d["l"].split(" / ")[0]}</span></td>'
        f'<td class="num">{rounds(d)}</td><td>{istatus(d)}</td></tr>'
        for d in m["intv_detail"])
    intv_note = ("Low interview volume, so individual rows are useful now. At higher volume this becomes a "
                 "<b>conversion-by-source / time-to-interview</b> view rather than a per-interview list.")
    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Job Search Dashboard — {period} — {today}</title>
<style>
:root{{--bg:#0f1115;--card:#181b22;--card2:#1f232c;--ink:#e7ebf0;--muted:#9aa4b2;--line:#2a2f3a;--accent:#6aa6ff;--good:#48c78e;--warn:#ffb454;--bad:#ff6b6b;--ai:#b388ff;}}
*{{box-sizing:border-box;margin:0;padding:0}}
body{{background:var(--bg);color:var(--ink);font:15px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;padding:32px;max-width:1100px;margin:0 auto}}
h1{{font-size:26px}}.sub{{color:var(--muted);margin:4px 0 28px;font-size:13px}}
h2{{font-size:15px;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin:32px 0 14px;font-weight:600}}
.grid{{display:grid;gap:14px}}.kpis{{grid-template-columns:repeat(4,1fr)}}.two{{grid-template-columns:1fr 1fr}}
.card{{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:18px}}
.kpi .n{{font-size:30px;font-weight:700;line-height:1}}.kpi .l{{color:var(--muted);font-size:12px;margin-top:6px}}.kpi .h{{font-size:11px;margin-top:8px;color:var(--muted)}}
.accent{{color:var(--accent)}}.good{{color:var(--good)}}.warn{{color:var(--warn)}}.bad{{color:var(--bad)}}.ai{{color:var(--ai)}}
table{{width:100%;border-collapse:collapse;font-size:14px}}th,td{{text-align:left;padding:9px 10px;border-bottom:1px solid var(--line)}}
th{{color:var(--muted);font-weight:600;font-size:12px;text-transform:uppercase;letter-spacing:.04em}}td.num,th.num{{text-align:right;font-variant-numeric:tabular-nums}}
.bar{{height:9px;border-radius:5px;background:var(--accent);display:inline-block;vertical-align:middle}}.bar.ai{{background:var(--ai)}}
.bartrack{{background:var(--card2);border-radius:5px;width:110px;display:inline-block;vertical-align:middle;overflow:hidden}}
.funnel-row{{display:flex;align-items:center;gap:14px;margin:9px 0}}.funnel-label{{width:120px;color:var(--muted);font-size:13px}}
.funnel-bar{{height:28px;border-radius:6px;display:flex;align-items:center;padding:0 12px;color:#0f1115;font-weight:700;font-size:13px;white-space:nowrap;min-width:fit-content}}
.pill{{display:inline-block;padding:2px 9px;border-radius:20px;font-size:11px;font-weight:600}}
.note{{color:var(--muted);font-size:12px;margin-top:10px;line-height:1.5}}.tag{{font-size:11px;padding:1px 7px;border-radius:5px;background:var(--card2);color:var(--muted)}}
ul{{margin:10px 0 0 18px}}
.refresh{{display:inline-flex;align-items:center;gap:6px;background:var(--accent);color:#0f1115;font-weight:700;font-size:14px;text-decoration:none;padding:9px 16px;border-radius:8px;transition:opacity .15s}}
.refresh:hover{{opacity:.85}}.refresh:active{{transform:translateY(1px)}}
.group-header{{font-size:10px;font-weight:500;text-transform:uppercase;letter-spacing:.12em;color:var(--accent);margin:2rem 0 .25rem;padding-bottom:.4rem;border-bottom:1px solid var(--line)}}
.banner{{background:linear-gradient(135deg,rgba(106,166,255,.14),rgba(179,136,255,.14));border:1px solid var(--line);border-left:3px solid var(--accent);border-radius:12px;padding:18px 22px;margin-bottom:8px}}
.banner-big{{font-size:20px;font-weight:700;color:var(--ink);margin-bottom:5px}}
.banner-text{{color:var(--muted);font-size:13.5px;line-height:1.6;white-space:nowrap}}
@media(max-width:760px){{.kpis{{grid-template-columns:repeat(2,1fr)}}.two{{grid-template-columns:1fr}}body{{padding:18px}}}}
</style></head><body>
<div style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap">
  <h1>Job Search Dashboard</h1>
  <a class="refresh" href="/regenerate" title="Re-read the tracker and rebuild this dashboard">&#8635; Refresh</a>
</div>
<div class="sub"><b>Project:</b> {os.path.basename(ROOT)} &middot; {period} &middot; {m['N']} applications &middot; generated {gen_at} &middot; click &#8635; Refresh to rebuild from the latest tracker data</div>

<div class="banner">
  <div class="banner-big">🌱 Keep planting.</div>
  <div class="banner-text">Nothing grows from nothing. The <b>{m['N']}</b> seeds you've planted are why <b>{len(m['intv'])}</b> are breaking ground 🌿 — you only need a few to bloom. Keep going. 💪</div>
</div>

<div class="group-header">Activity</div>
<h2>Headline</h2>
<div class="grid kpis" style="grid-template-columns:repeat(3,1fr)">
<div class="card kpi"><div class="n">{m['N']}</div><div class="l">Total applications</div><div class="h">across {len(months)} months &middot; ~{round(total_eff/max(len(months),1))}/month</div></div>
<div class="card kpi"><div class="n warn">{intv_rate:.1f}%</div><div class="l">Interview rate</div><div class="h">{len(m['intv'])} unique companies &middot; {m['total_rounds']} total rounds</div></div>
<div class="card kpi"><div class="n accent">{len(m['recs_r'])}</div><div class="l">Recruiter contacts</div><div class="h">{len(m['r_warm'])} warm &middot; {len(m['r_inbound'])} inbound &middot; {len(m['r_outbound'])} outreach</div></div>
</div>
<div class="grid kpis" style="grid-template-columns:repeat(3,1fr);margin-top:14px">
<div class="card kpi"><div class="n bad">{ghost:.1f}%</div><div class="l">Ghost / no-response</div><div class="h">{len(m['noresp'])} never replied</div></div>
<div class="card kpi"><div class="n bad">{rej_rate:.1f}%</div><div class="l">Rejected rate</div><div class="h">{len(m['rej'])} rejected</div></div>
<div class="card kpi"><div class="n warn">{pct(len(m['pend']),m['N']):.0f}%</div><div class="l">Active / pending</div><div class="h">{len(m['pend'])} still open</div></div>
</div>

<h2>Pipeline overview</h2>
<div class="card">
  <div class="grid" style="grid-template-columns:repeat(5,1fr)">
    <div class="kpi"><div class="n">{m['assessed']}</div><div class="l">Roles assessed</div></div>
    <div class="kpi"><div class="n accent">{m['N']}</div><div class="l">Applied</div></div>
    <div class="kpi"><div class="n">{m['passed']}</div><div class="l">Did not apply</div></div>
    <div class="kpi"><div class="n ai">{m['pass_interested']}</div><div class="l">Passed but interested</div></div>
    <div class="kpi"><div class="n">{m['withdrawn']}</div><div class="l">Withdrawn</div></div>
  </div>
  <div class="note">Full pipeline from evaluation onward. <b>Assessed</b> = roles formally scored via /assess-role. <b>Did not apply</b> = assessed but never submitted (gap or not pursuing). <b>Passed but interested</b> = never submitted either, but deliberately deferred to build skills first and pursue later (e.g. dream-tier) &mdash; a "not yet," not a "no." <b>Withdrawn</b> = was in an active interview process and then stepped out (reserved for that case only; rare). The funnel below covers the {m['N']} applied.</div>
</div>

<h2>Effort over time</h2>
<div class="card">{bar_svg(months)}
<div class="note">Total this period: <b>{total_eff}</b> applications across {len(months)} months.</div></div>

<div class="group-header">Conversion</div>
<h2>Funnel</h2>
<div class="card">{funnel_html(m)}
<div class="note">All stages shown even when empty. Biggest leak is top-of-funnel: {ghost:.0f}% never reply.</div></div>

<h2>Conversion by Lane</h2>
<div class="card"><table>
<tr><th>Lane</th><th class="num">Apps</th><th class="num">Intv</th><th class="num">Interview rate</th><th class="num">Pending</th></tr>
{''.join(lane_rows)}
</table><div class="note">Ranked by interview rate. <span style="color:var(--good)">Top lane</span> and <span style="color:var(--accent)">runner-up</span> highlighted. Small samples &mdash; read as direction, not precision.</div></div>

<h2>Pending pipeline by lane</h2>
<div class="card two grid"><div><table><tr><th>Lane</th><th class="num">Pending</th></tr>{pend_rows}</table></div>
<div class="note" style="margin-top:0"><b>What to watch:</b> these open applications are what will confirm or break your current focus. As they resolve into interviews or rejections, the lane with the highest interview rate tells you where to concentrate effort next.</div></div>

<h2>Interview log <span style="text-transform:none;font-weight:400;color:var(--muted);font-size:13px">&middot; {len(m['intv'])} reached, {len(m['intv_active'])} active</span></h2>
<div class="card"><table>
<tr><th>Applied</th><th>Company</th><th>Lane</th><th class="num">Rounds</th><th>Status</th></tr>{intv_rows}</table>
<div class="note">{intv_note}</div></div>

<h2>Recruiter activity</h2>
<div class="card">
  <div class="grid" style="grid-template-columns:repeat(4,1fr)">
    <div class="kpi"><div class="n">{len(m['recs_r'])}</div><div class="l">Total contacts</div><div class="h">{len(m['r_warm'])} warm · {len(m['r_inbound'])} inbound · {len(m['r_outbound'])} outreach</div></div>
    <div class="kpi"><div class="n good">{len(m['r_in_convo']) + len(m['r_pending']) + len(m['r_new'])}</div><div class="l">Active</div><div class="h">{len(m['r_in_convo'])} in conversation · {len(m['r_pending'])} pending reply · {len(m['r_new'])} new</div></div>
    <div class="kpi"><div class="n accent">{len(m['r_role_opened']) + len(m['r_applied'])}</div><div class="l">Led to a role</div><div class="h">{len(m['r_applied'])} applied · {len(m['r_interviewed'])} interviewed</div></div>
    <div class="kpi"><div class="n" style="color:var(--muted)">{len(m['r_no_fit']) + len(m['r_stale'])}</div><div class="l">Not active</div><div class="h">{len(m['r_no_fit'])} no fit · {len(m['r_stale'])} stale</div></div>
  </div>
  <div style="margin-top:18px">
  {'<table><tr><th>First contact</th><th>Recruiter</th><th>Company</th><th>Type</th><th>Status</th><th>Last contact</th></tr>' + ''.join(f'<tr><td style="color:var(--muted);font-size:13px">{r.get("Date_First_Contact","")}</td><td>{r.get("Recruiter_Name","")}</td><td>{r.get("Company","")}</td><td><span class="tag">{r.get("Type","")}</span></td><td><span class="tag" style="color:{"var(--good)" if r.get("Status","").lower()=="in conversation" else "var(--accent)" if r.get("Status","").lower() in ("new","keeping warm") else "var(--muted)" if r.get("Status","").lower() in ("stale","not fit") else "var(--muted)"}">{r.get("Status","")}</span></td><td style="color:var(--muted);font-size:13px">{r.get("Last_Contact","")}</td></tr>' for r in sorted(m['recs_r'], key=lambda x: x.get('Date_First_Contact',''), reverse=True)) + '</table>' if m['recs_r'] else '<div class="note">No recruiter contacts logged yet.</div>'}
  </div>
  <div class="note" style="margin-top:12px">Conversion funnel: Contacted → Active → Role Opened → Applied → Interviewed. Tracked in recruiter_tracker.csv — update Status as relationships progress.</div>
</div>

{render_caveated(m)}

{narrative(m)}

{render_insights()}

<div class="note" style="margin-top:24px"><b>Method:</b> stage values normalized; lanes derived from role category; no per-stage dates yet (so no time-to-interview). Sections marked &#9888; will firm up as field coverage grows.</div>
</body></html>"""

# ---------- main ----------
def main():
    period = sys.argv[1] if len(sys.argv) > 1 else "to-date"
    ref = sys.argv[2] if len(sys.argv) > 2 else None
    today = datetime.date.today().isoformat()
    recs = load()
    # period filtering on application date
    if period == "weekly":
        cutoff = (datetime.date.today() - datetime.timedelta(days=7)).isoformat()
        if ref: cutoff = (datetime.date.fromisoformat(ref) - datetime.timedelta(days=7)).isoformat()
        recs_f = [d for d in recs if d["date"] >= cutoff] or recs
        label = f"Weekly (since {cutoff})"
        recs_used = recs  # funnel always whole; weekly view notes new activity
    elif period == "monthly":
        mon = ref or today[:7]
        label = f"Monthly ({mon})"
        recs_used = recs
    else:
        period = "to-date"; label = "To Date"; recs_used = recs
    m = compute(recs_used)
    os.makedirs(OUTDIR, exist_ok=True)
    html = render_html(m, label, today)
    md = render_md(m, label, today)
    # dated + latest
    for name, content in [
        (f"job_search_dashboard_{period}_{today}.html", html),
        ("job_search_dashboard_latest.html", html),
        (f"job_search_report_{period}_{today}.md", md),
        ("job_search_report_latest.md", md),
    ]:
        with open(os.path.join(OUTDIR, name), "w") as f:
            f.write(content)
    print(f"[dashboard] {period} regenerated {today}: {m['N']} apps, {len(m['intv'])} companies interviewed ({m['total_rounds']} total rounds) -> 06_OUTPUTS/reports/job_search_dashboard_latest.html")

if __name__ == "__main__":
    main()
