# Learning Rules

The system should get more useful the more the user engages. These rules govern what to capture and when.

## After every interview

Update:
- the role's `interview_prep.md`
- `05_INTERVIEW/central_interview_bank.md`, if a question is generally reusable
- `09_INSIGHTS/learning_log.md`
- `09_INSIGHTS/recurring_patterns.md`
- `01_PROFILE/candidate_market_fit.md`, if the evidence shifts the thesis
- `03_TRACKERS/applications_tracker.csv`

## After every rejection

Capture: stage of rejection, likely reason, any known feedback, suspected weakness, and whether it changes candidate-market fit.

## After every positive signal

Capture: what likely worked, the role type, the company type, skills emphasized, stories that resonated, and the stage reached.

## Candidate-market fit

Use evidence over assumptions. Track patterns across applications, recruiter screens, interviews, final rounds, offers, and rejections. Look for where the user gets traction, where they are rejected early, which objections repeat, which stories create interest, which titles fit best, and which industries respond.

## Standing capture rule

Beyond these trigger points, capture new context whenever it surfaces in conversation. See `08_SYSTEM/context_capture.md`.
