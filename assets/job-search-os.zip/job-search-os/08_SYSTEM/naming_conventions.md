# Naming Conventions

Use lowercase filenames with underscores.

## Company / role slugs

Format: `company_role`

Examples:
- `acme_senior_program_manager`
- `northwind_operations_lead`
- `globex_product_manager`

## Output files

Format: `company_role_outputtype_YYYY-MM-DD.md`

Examples:
- `acme_senior_program_manager_assessment_2026-06-11.md`
- `acme_senior_program_manager_cv_2026-06-11.md`
- `acme_senior_program_manager_cover_letter_2026-06-11.md`

## Where each output type lives

- Assessments → `04_ASSESSMENTS/assessments/`
- Gap plans → `04_ASSESSMENTS/gap_roles/`
- CVs → `06_OUTPUTS/cvs/`
- Cover letters → `06_OUTPUTS/cover_letters/`
- Application answers → `06_OUTPUTS/application_questions/`
- Recruiter messages → `06_OUTPUTS/recruiter_messages/`
- LinkedIn → `06_OUTPUTS/linkedin/`
- Shortlists → `06_OUTPUTS/shortlists/`
- Reports and dashboard → `06_OUTPUTS/reports/`

## Role-specific interview files

Each role gets one folder and one prep file:

`05_INTERVIEW/role_specific/company_role/interview_prep.md`

All rounds stay inside that file. Copy the `_template_company_role` folder to start a new role.
