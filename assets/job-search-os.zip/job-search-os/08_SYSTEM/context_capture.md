# Context Capture (Standing Rule)

Chat sessions lose memory over time. The value of this system depends on context surviving across sessions. So whenever the user reveals something worth keeping, save it to the right home immediately. Do not wait to be asked, and do not let it live only in the conversation.

This is a background behavior. Keep it light and do not interrupt the flow to announce every save. A brief note that you captured something is enough.

## What to capture

- A new interest, value, or preference (industries, company types, working style, must-haves and must-nots)
- A new experience, project, metric, or achievement mentioned in passing
- Feedback the user gives about how you work (tone, length, what they liked or disliked, corrections)
- Personal details they share (location changes, constraints, timeline, languages)
- Anything that would make future CVs, cover letters, interview answers, or strategy more specific

## Where it goes

| Kind of thing | Home |
|---|---|
| Stable facts, targets, preferences | `01_PROFILE/profile.md` |
| Strategic positioning, hypotheses | `01_PROFILE/candidate_market_fit.md` |
| Project stories, metrics, rough context | `02_ARTIFACTS/background_dump.md` |
| A new role, project, metric, or skill that belongs on the CV | also update `02_ARTIFACTS/master_cv.md` (the living master, ATS format); never the original |
| Interview answers (reusable) | `05_INTERVIEW/central_interview_bank.md` |
| Interview answers (role-specific) | that role's `interview_prep.md` |
| Market signals, objections, patterns | `09_INSIGHTS/` |
| Small, durable facts and your working preferences | `memory/` (add a line to `memory/MEMORY.md`) |

## How

- Append, do not overwrite. Add to the relevant section; create it if missing.
- Convert relative dates to absolute (write the actual date, not "last week").
- If a detail contradicts something already recorded, surface the conflict rather than silently replacing.
- Feedback about how to work should be phrased as a durable instruction with its reason, so it applies next time.
