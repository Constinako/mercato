# Commands

The full specification for every command in the system. Commands are grouped so the ones you use most are numbered by the order you use them.

## Command groups

**Primary (numbered by flow):**

| Command | What it does |
|---|---|
| `/1-assess` | Assess a job description and decide whether to apply |
| `/2-apply` | Generate a tailored CV, cover letter, and optional recruiter message |
| `/3-interview` | Forecast questions, prep and polish answers, run a mock, and coach |
| `/4-dashboard` | Rebuild and open the metrics + insights dashboard |
| `/5-linkedin` | LinkedIn audit, strategy, or a post |
| `/6-website` | Build a personal website |

**Secondary (run occasionally or automatically):** `/pass-but-interested`, `/capture-learning`, `/update-status`, `/add-to-profile`, `/import-roles`, `/weekly-shortlist`, `/recheck-gaps`.

**Course navigation:** `/start`, `/start-1` … `/start-6`.

## Three-layer tracker

Every role passes through up to three layers. Only `/2-apply` crosses from evaluation to committed application.

| Layer | File | Written by |
|---|---|---|
| Discovery (optional) | `03_TRACKERS/role_intake_queue.csv` | `/import-roles` |
| Evaluation | `03_TRACKERS/role_assessments.csv` | `/1-assess`, `/pass-but-interested` |
| Application | `03_TRACKERS/applications_tracker.csv` | `/2-apply` only |

## Shared vocabulary

These value sets are used across the trackers and the dashboard. They are intentionally general. A user should edit the Role Category list to fit their own field.

**Role Category** (pick one, edit to fit the user):
- `Product`, `Operations`, `Strategy`, `Program-Project`, `Marketing-Growth`, `Sales-BD`, `Customer-Success`, `Data-Analytics`, `Engineering-Technical`, `Design`, `People-HR`, `Finance`, `Non-Tech`, `Other`

**Work Type** (pick one): `Remote`, `Remote (base: <city>)`, `Remote (base: <region>)`, `Hybrid`, `In-Office`, `Unknown`

**Pipeline Stage** (pick one): `Applied`, `No Response`, `On Hold`, `Interview Invited`, `Round 1`, `Round 2+`, `Rejected`, `Rejected Post-Interview`, `Offer`, `Withdrawn`, `Pass – Gap`, `Keeping Warm`, `Recruiter Inbound`, `Recruiter Outreach`, `Recruiter Intro`

---

## /1-assess

Use when the user pastes a job description and wants to decide whether to apply.

**Input:** a job description (pasted or linked). Optional: company, role title, location, salary range, reason interested.

**Agents:** Career Strategist + ATS Specialist.

**Output:** save a full narrative assessment to `04_ASSESSMENTS/assessments/company_role_assessment_YYYY-MM-DD.md`, and append one row to `03_TRACKERS/role_assessments.csv`.

Assessment file includes: Company, Role, Location, Date, ATS Match Score (Master CV), ATS Match Score (Optimized CV, with a note on what changes close the gap), Market Fit Score, Interview Probability, Estimated Salary Range, Salary Confidence, Salary Fit (compare to `01_PROFILE/profile.md`; flag if likely below the user's floor), Salary Expectations Guidance (single number, range, one-sentence rationale), Career Alignment, Seniority Match, Strengths, Risks, Missing Requirements, Missing Keywords, Recommendation (Apply / Maybe Apply / Do Not Apply), Reason, Suggested next step.

CSV row fields: `Date_Assessed, Company, Role_Title, Role_Category, Work_Type, Location, ATS_Score_Master, ATS_Score_Optimized, Market_Fit_Score, Interview_Probability, Salary_Estimate, Salary_Fit, Recommendation, Shortlist_Status, Assessment_File, Job_URL, Notes`.

Set `Shortlist_Status`:
- `Shortlisted` — Recommendation is Apply, OR Maybe Apply with Interview_Probability >= 25%
- `Below_Threshold` — Maybe Apply with Interview_Probability < 25%, or Do Not Apply
- `Gap` — routed to `/pass-but-interested`

Do not generate a CV or cover letter. Do not write to `applications_tracker.csv`. After the assessment, offer the user three paths: apply now (`/2-apply`), pass but stay interested (`/pass-but-interested`), or move on.

### Assessment file layout (use tables, not flat bullets)

Format the saved assessment file like this:

1. **Header block:** Date, Company (with a one-line descriptor), Role, Location, Employment Type, Salary (as listed or "not stated"), Source.
2. **Scores table** (`| Signal | Score |`): ATS Match Score (Master CV), ATS Match Score (Optimized CV) with an inline note on what closes the gap, Market Fit Score, Interview Probability.
3. **Compensation table** (`| | |`): Estimated Salary Range (with a Salary Confidence note), and **Salary Expectations Guidance** = what to actually put down if the application asks, given as both a recommended single number and a recommended range, a one-line rationale, and a salary-fit check against the user's floor in `01_PROFILE/profile.md` (flag clearly if the role is likely below it).
4. **Strategic Assessment:** short prose sections (Career Alignment, Seniority Match, Location/Culture, and any role-specific angle).
5. **ATS Analysis:** the score-delta explanation, Keyword Coverage (present vs missing), and a **Requirement Match table** (`| Requirement | Match | Notes |`).
6. **Strengths** and **Risks** (numbered lists).
7. **Missing Requirements** and **Missing Keywords**.
8. **Recommendation** (Apply / Maybe Apply / Do Not Apply) with a reason.
9. **Suggested Next Steps** (numbered).

Reference example (Marie's live system, same format): a header block, a Scores table, a Compensation table, strategic prose, and a Requirement Match table.

---

## /2-apply

Use when the user has decided to apply. Absorbs the old "promote from shortlist" flow: if an assessment already exists for this role, read it first instead of re-assessing.

**Input:** a job description. Optional: existing assessment, company notes, salary notes, specific concerns.

**Agents:** ATS Specialist, Application Writer, Authenticity Editor, Knowledge Manager.

**Output:** one optimized CV, one cover letter, and an optional recruiter message. Cover letters include a salutation and a sign-off.
- `06_OUTPUTS/cvs/company_role_cv_YYYY-MM-DD.md`
- `06_OUTPUTS/cover_letters/company_role_cover_letter_YYYY-MM-DD.md`
- `06_OUTPUTS/recruiter_messages/company_role_recruiter_message_YYYY-MM-DD.md` (when useful)

Append a row to `03_TRACKERS/applications_tracker.csv` with Pipeline Stage = Applied. If this role came from an assessment, update that assessment row's Shortlist_Status to `Promoted`.

Rules: do not create multiple CV versions. Ask up to 3 high-value questions only if needed. Run the Authenticity Editor before final output.

---

## /3-interview

Use when the user has an interview or wants to prepare for a possible round.

**Input:** company, role, round number, interview type, interviewer type or seniority, job description, previous round notes, feedback received. Optional but highly recommended: **interviewer intel** (who they are, LinkedIn screenshots/export, their posts or articles, a link to their site, so their lens can be read) and the **company website / careers page** (to extract values, vision, mission, product signals).

**Agents:** Interview Coach, Authenticity Editor, Knowledge Manager.

**What it does:** (1) forecast likely questions for this stage, interviewer, company, and industry, organized into sections A Opening / B Role-specific / C Behavioural / D Technical-domain / E Company-mission, plus the follow-up questions an interviewer would likely probe with; also prepare **Section F, questions to ask the interviewer**, as both a suggested focus list AND a backup pool (depth-oriented, "Never Search Alone" ethos), and **flag risks and how to address them**; (2) prepare and polish answers; (3) optionally run a live mock interview, one question at a time, progressing naturally from warm openers to depth (not aggressive, not jumping into hard specifics too soon); (4) coach: strengths, what to work on, practical next steps.

**Output and saving (required):**
- Reusable, role-agnostic answers → `05_INTERVIEW/central_interview_bank.md`
- Role-specific questions and polished answers → `05_INTERVIEW/role_specific/company_role/interview_prep.md` (create from the `_template_company_role` folder if new; all rounds stay in this one file)

Never end an interview session without saving the polished questions and answers. This is the most common thing to forget, so treat it as mandatory.

When this command is run inside the course demo and the user declines a live mock, still generate a short zero-input sample prep, save it, and show it, so the feature is never skipped (see `00_COURSE/course_map.md`).

---

## /4-dashboard

Rebuild and open the dashboard: metrics on top, strategic synthesis below.

**What it does:**
1. Read across `09_INSIGHTS/` and the trackers, and refresh the distilled synthesis in `09_INSIGHTS/insights_synthesis.md` (Candidate-Market Fit Hypothesis, Tracks & Skills, Insights). This synthesis is Claude's job and must be done before rendering.
2. Run the generator (single source of truth):
   ```
   python3 "$CLAUDE_PROJECT_DIR/08_SYSTEM/scripts/generate_dashboard.py" [to-date|weekly|monthly] [YYYY-MM-DD|YYYY-MM]
   ```
   It writes a dated report plus stable `_latest` files into `06_OUTPUTS/reports/`.
3. Start the local server so the Refresh button works and open it:
   ```
   python3 "$CLAUDE_PROJECT_DIR/08_SYSTEM/scripts/serve_dashboard.py" 8789
   ```
   Then open `http://localhost:8789/job_search_dashboard_latest.html`.

The generator also auto-runs via a PostToolUse hook whenever `applications_tracker.csv` is edited, so `_latest` stays current. The dashboard is read-only: it never modifies the CSVs. If a metric definition needs to change, edit the script, not a hand computation. State data-quality caveats honestly rather than fabricating cuts the data cannot support.

`/report [weekly|monthly|to-date]` is the same engine if the user wants only the markdown report.

---

## /5-linkedin

One command, three modes. Ask which the user wants, or infer from context.

- **Audit** — paste the current LinkedIn profile (headline, about, experience, skills). Output a scored audit with prioritized rewrites → `06_OUTPUTS/linkedin/linkedin_audit_YYYY-MM-DD.md`.
- **Strategy** — build a content strategy and posting calendar from the profile → `06_OUTPUTS/linkedin/linkedin_strategy_YYYY-MM-DD.md`.
- **Post** — draft a specific post (hooks, final post, optional shorter version) → `06_OUTPUTS/linkedin/topic_YYYY-MM-DD.md`.

**Agents:** LinkedIn Strategist, ATS Specialist (for audit keywords), Authenticity Editor (mandatory on all copy).

---

## /6-website

Build the user's personal website.

**Agent:** Website Builder.

**What it does:** ask a focused set of questions (career direction, projects, styling, inspiration, existing site to pull from, blog yes/no), decide structure and content by industry standard and target roles, generate the site into `06_OUTPUTS/website/`, and show a local preview. Publishing (domain purchase, GitHub, going live) happens only on the user's explicit signal. See the Website Builder agent for the full flow.

---

## /pass-but-interested

Use when a role is genuinely interesting but has real gaps that make applying now unrealistic. This is an investment decision, not a rejection.

**Agents:** Career Strategist, ATS Specialist, Knowledge Manager.

**Output:** a gap plan → `04_ASSESSMENTS/gap_roles/company_role_gap_plan_YYYY-MM-DD.md` (role summary, honest current match, hard gaps, soft gaps, a gap map with time estimates and actions, a sequenced 3 to 12 month path, role tier). Then update `04_ASSESSMENTS/gap_roles_strategy.md` to synthesize across all gap roles (common gaps, highest-leverage investments, tiers, one game plan). Write one row to `03_TRACKERS/role_assessments.csv` with Recommendation = Pass – Gap and Shortlist_Status = Gap. Do not write to the applications tracker. Do not generate a CV.

---

## /capture-learning

Use after an interview, rejection, feedback, or meaningful practice.

**Input:** company, role, round, outcome, questions asked, the user's answers, what went well and poorly, feedback, next step.

**Agents:** Knowledge Manager, Interview Coach, Career Strategist.

**Updates:** `05_INTERVIEW/central_interview_bank.md`, the role's `interview_prep.md`, `09_INSIGHTS/learning_log.md`, `09_INSIGHTS/recurring_patterns.md`, `01_PROFILE/candidate_market_fit.md`, and `03_TRACKERS/applications_tracker.csv`. Output: lessons captured, answers improved, patterns detected, next focus, status update.

---

## /update-status

Use on any status change: rejected, invited, moved forward, offer, withdrawn.

**Input:** company, role, new status, date, notes.

Update the matching row in `03_TRACKERS/applications_tracker.csv` using the Pipeline Stage vocabulary above. Tracker columns: `Date, Company, Role, Role Category, Work Type, Location, Pipeline Stage, Interview_Rounds, ATS Match Score, Market Fit Score, Interview Probability, Estimated Salary Range, Recommendation, Source Assessment, Job URL, Notes`.

---

## /add-to-profile

Use to enrich the profile deliberately. Interview the user with focused questions (targets, salary history plus target and floor, strengths, gaps, preferences, goals, anything missing from `01_PROFILE/profile.md`), offering pick-from options for categorical questions and short examples for open ones, letting them skip freely, and write their answers into `profile.md` and, where relevant, `candidate_market_fit.md`. Capture what they currently or previously earned, and note that the salary target can shift by location. Offer this any time the profile is thin.

---

## /import-roles

Use to manually add roles found outside any automation (a LinkedIn post, a referral, browsing a job board). Append one row per role to `03_TRACKERS/role_intake_queue.csv` with Status = New. No assessment runs. Does not write to the other trackers.

---

## /weekly-shortlist

Surface assessed roles worth acting on. Reads `03_TRACKERS/role_assessments.csv`:
- Tier 1: Recommendation = Apply
- Tier 2: Maybe Apply with Interview_Probability >= 25%
- Excludes already-Promoted rows; defaults to the last 7 days.

Save to `06_OUTPUTS/shortlists/shortlist_YYYY-MM-DD.md`. Read-only, updates no CSV.

---

## /recheck-gaps

Use after the master CV or experience has changed, or periodically. Compares current experience against every gap plan in `04_ASSESSMENTS/gap_roles/` to see which gaps have closed and whether any gap role is now worth applying for.

**Agents:** Career Strategist (gap-tracking lens), ATS Specialist.

**Output:** a recheck report → `09_INSIGHTS/gap_recheck_YYYY-MM-DD.md`, and update `04_ASSESSMENTS/gap_roles_strategy.md` tiers and game plan. Flag clearly, without softening, any gap that is still open.

---

## /start and /start-1 … /start-6

Run the interactive course. `/start` begins at the welcome and overview. `/start-N` jumps to a module. The course scripts live in `00_COURSE/`; see `00_COURSE/course_map.md` for how to perform them.
