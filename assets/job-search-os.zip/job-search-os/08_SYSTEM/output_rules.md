# Output Rules

## Where things go

- Generated content belongs in `06_OUTPUTS/` (assessments and gap plans in `04_ASSESSMENTS/`).
- Knowledge updates belong in the relevant knowledge files (`05_INTERVIEW/`, `09_INSIGHTS/`, `01_PROFILE/`).
- Never overwrite source files: `02_ARTIFACTS/original_cv.md` and anything in `02_ARTIFACTS/uploads/`.

## One CV rule

For each role, create one optimized CV. Do not create an ATS CV, a human CV, a short CV, and a long CV. One strong CV that performs well with both ATS and humans, unless the user explicitly asks for a variant.

## CV structure (always this order)

Every generated CV uses the standard optimized format, not the layout of the user's original CV:

1. Contact
2. Summary (three sentences max)
3. Key Achievements (three to five strongest, quantified wins, at the top)
4. Experience (max 5 bullets for the two most recent roles, max 3 for earlier ones; each under 20 words, strong action verb, a metric even if approximate)
5. Education / Certifications / Projects
6. Skills, grouped into categories, at the bottom

This format is ATS-friendly rather than decorative. Note to the user that a more creative template may suit some industries or smaller companies; that is their call.

## Master CV upkeep

`02_ARTIFACTS/original_cv.md` is the frozen source and is never edited. `02_ARTIFACTS/master_cv.md` is a living document in the standard format above. Rebuild it from the original during setup, and update it whenever the user shares new relevant experience, a project, a metric, or a skill, so tailoring always starts from current material.

## Interview bank rules

- Reusable, role-agnostic questions and answers → `05_INTERVIEW/central_interview_bank.md`
- Role-specific questions and answers → `05_INTERVIEW/role_specific/company_role/interview_prep.md` (one file per role, all rounds inside)
- After any mock or answer polishing, saving is mandatory. Do not finish without persisting the improved answers.

## Website output

Any generated personal website (`06_OUTPUTS/website/`) must be responsive across mobile, tablet, and desktop, and must never ship unstyled. If the user gives no styling direction, infer a tasteful, modern look from their industry and career. See `07_AGENTS/website_builder.md`.

## Authenticity review

Before finalizing anything external-facing or spoken, apply the Authenticity Editor: CVs, cover letters, recruiter messages, interview answers, LinkedIn posts. Not required for analytical outputs like assessments or tracker updates.

## House style

Write like a specific person who lived the experience, not like a language model.

- **Avoid em dashes (—).** They are a common AI tell. Use commas, periods, or restructured sentences. One occasional em dash is tolerable; several in a document is not.
- Replace abstractions with evidence. "I aligned six teams working toward different priorities and got the project moving" beats "strong stakeholder management skills."
- Vary sentence rhythm. Allow short sentences and directness. Avoid repeated sentence structures and generic transitions.
- Cut inflated adjectives, consultant speak, and claims written to sound impressive.
- Keep CV bullets under 20 words, starting with a strong action verb, each carrying a metric even if approximate.
- Keep CV summaries to three sentences: experience, key roles, current focus. No aspirational filler.
