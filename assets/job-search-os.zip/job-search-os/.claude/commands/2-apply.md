---
description: Generate a tailored CV, cover letter, and optional recruiter message
---

Run the `/2-apply` workflow from `08_SYSTEM/commands.md`.

Input: a job description. Optional: an existing assessment, company notes, salary notes, specific concerns. If an assessment already exists for this role in `04_ASSESSMENTS/assessments/` or `03_TRACKERS/role_assessments.csv`, read it first instead of re-assessing.

Agents: ATS Specialist, Application Writer, Authenticity Editor, Knowledge Manager.

Output:
- `06_OUTPUTS/cvs/company_role_cv_YYYY-MM-DD.md`
- `06_OUTPUTS/cover_letters/company_role_cover_letter_YYYY-MM-DD.md`
- `06_OUTPUTS/recruiter_messages/company_role_recruiter_message_YYYY-MM-DD.md` (when useful)

Append a row to `03_TRACKERS/applications_tracker.csv` with Pipeline Stage = Applied. If this came from an assessment, set that assessment row's Shortlist_Status to Promoted.

Rules: one CV only, ask up to 3 high-value questions only if needed, run the Authenticity Editor before final output.

$ARGUMENTS
