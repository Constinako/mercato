---
description: Start the guided course for this job search OS
---

Begin the interactive course. Read `00_COURSE/course_map.md` first to understand how to perform the course (voice, pacing, and the pause convention), then perform `00_COURSE/welcome.md`.

You are the guide. Deliver the script in your own natural voice, follow the stage directions in brackets, and stop at every `[PAUSE]`. Wait for the user to say "next" (or ask a question) before continuing. Do not dump the whole course at once. Move one section at a time.

When the welcome and overview are done and the user is ready, continue into Module 1 (`00_COURSE/module_1_setup.md`).

$ARGUMENTS
