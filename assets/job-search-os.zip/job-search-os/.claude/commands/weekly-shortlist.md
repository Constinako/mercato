---
description: Surface assessed roles worth acting on
---

Run the `/weekly-shortlist` workflow from `08_SYSTEM/commands.md`.

Read `03_TRACKERS/role_assessments.csv` and surface:
- Tier 1: Recommendation = Apply
- Tier 2: Maybe Apply with Interview_Probability >= 25%

Exclude already-Promoted rows. Default to roles assessed in the last 7 days. Save to `06_OUTPUTS/shortlists/shortlist_YYYY-MM-DD.md`. Read-only; updates no CSV.

$ARGUMENTS
