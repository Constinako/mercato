---
description: Manually add roles to the intake queue
---

Run the `/import-roles` workflow from `08_SYSTEM/commands.md`.

For roles found outside any automation (a LinkedIn post, a referral, browsing a job board). Each needs at least a company, a role title, and either a URL or a pasted JD. Optional: location, salary, source, department.

Append one row per role to `03_TRACKERS/role_intake_queue.csv` with Status = New. No assessment runs; that is a separate step (`/1-assess`). Does not write to the other trackers.

$ARGUMENTS
