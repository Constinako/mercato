---
description: Log a role you are not ready for yet and build a gap plan
---

Run the `/pass-but-interested` workflow from `08_SYSTEM/commands.md`.

For a role that is genuinely interesting but has real gaps. An investment decision, not a rejection.

Agents: Career Strategist, ATS Specialist, Knowledge Manager.

Output:
- A gap plan → `04_ASSESSMENTS/gap_roles/company_role_gap_plan_YYYY-MM-DD.md` (role summary, honest current match, hard gaps, soft gaps, a gap map with time estimates and actions, a sequenced 3 to 12 month path, role tier).
- Update `04_ASSESSMENTS/gap_roles_strategy.md` to synthesize across all gap roles.
- Write one row to `03_TRACKERS/role_assessments.csv` with Recommendation = Pass – Gap and Shortlist_Status = Gap.

Do not write to the applications tracker. Do not generate a CV.

$ARGUMENTS
