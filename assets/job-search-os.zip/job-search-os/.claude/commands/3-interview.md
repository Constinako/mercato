---
description: Forecast questions, prep and polish answers, run a mock, and coach
---

Run the `/3-interview` workflow from `08_SYSTEM/commands.md`.

Input: company, role, round number, interview type, interviewer type or seniority, job description, previous round notes, feedback received.

Agents: Interview Coach, Authenticity Editor, Knowledge Manager.

Do: (1) forecast likely questions for this stage, interviewer, company, and industry; (2) prepare and polish answers; (3) optionally run a live mock interview, one question at a time; (4) coach with strengths, what to improve, and practical next steps.

Saving is mandatory. Persist polished questions and answers before finishing:
- Reusable, role-agnostic answers → `05_INTERVIEW/central_interview_bank.md`
- Role-specific answers → `05_INTERVIEW/role_specific/company_role/interview_prep.md` (create from the `_template_company_role` folder if new; keep all rounds in the one file).

Never end the session without saving.

$ARGUMENTS
