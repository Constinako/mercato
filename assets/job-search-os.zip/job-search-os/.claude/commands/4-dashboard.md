---
description: Rebuild and open the metrics + insights dashboard
---

Run the `/4-dashboard` workflow from `08_SYSTEM/commands.md`.

1. Read across `09_INSIGHTS/` and the trackers, then refresh the distilled synthesis in `09_INSIGHTS/insights_synthesis.md` (Candidate-Market Fit Hypothesis, Tracks & Skills, Insights). Do this before rendering.
2. Regenerate:
   ```
   python3 "$CLAUDE_PROJECT_DIR/08_SYSTEM/scripts/generate_dashboard.py" to-date
   ```
3. Serve and open it:
   ```
   python3 "$CLAUDE_PROJECT_DIR/08_SYSTEM/scripts/serve_dashboard.py" 8789
   ```
   Then open `http://localhost:8789/job_search_dashboard_latest.html`.

The dashboard is read-only and never modifies the CSVs. If the data is sparse, say so honestly rather than inventing cuts. For a markdown-only report, use `/report [weekly|monthly|to-date]` (same engine).

$ARGUMENTS
