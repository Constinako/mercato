---
description: Jump to Module 2a: Assess a role
---

Jump straight to **Module 2a: Assess a role** within Module 2 (Core Features). If you have not already, read `00_COURSE/course_map.md` for how to perform the course (voice, pacing, clickable file links, quick-select options, never skipping a demo feature, and the `[PAUSE]` convention). Then open `00_COURSE/module_2_use_it.md` and perform the section headed "## Module 2a: Assess a role", continuing from there.

You are the guide. Deliver it in your natural voice, follow the bracketed stage directions, keep chunks short with tasteful emojis, and stop at every `[PAUSE]` to wait for the user.

$ARGUMENTS
