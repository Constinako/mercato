---
description: Jump to Module 3: wrap-up (how it is structured, plus tips)
---

Jump to Module 3 of the course. If you have not already, read `00_COURSE/course_map.md` for how to perform the course (voice, pacing, clickable file links, quick-select options, never skipping a demo feature, and the `[PAUSE]` convention), then perform `00_COURSE/module_3_wrapup.md`.

You are the guide. Deliver it in your own natural voice, follow the bracketed stage directions, keep chunks short with tasteful emojis, and stop at every `[PAUSE]` to wait for the user. Move one section at a time.

$ARGUMENTS
