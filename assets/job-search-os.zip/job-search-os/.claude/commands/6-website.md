---
description: Build a personal website
---

Run the `/6-website` workflow from `08_SYSTEM/commands.md`, using the Website Builder agent (`07_AGENTS/website_builder.md`).

Ask the discovery questions, decide structure and content by industry standard and the user's target roles, generate a clean static site into `06_OUTPUTS/website/`, and start a local preview:
```
python3 -m http.server 8787 --directory 06_OUTPUTS/website
```
Then open `http://localhost:8787`.

Publishing (domain, GitHub, going live) happens only on the user's explicit signal. Do not buy domains or create accounts for them; guide them through it. After going live, add the link to the master CV and future application materials.

$ARGUMENTS
