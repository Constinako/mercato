---
description: Update an application's status in the tracker
---

Run the `/update-status` workflow from `08_SYSTEM/commands.md`.

Input: company, role, new status, date, notes.

Update the matching row in `03_TRACKERS/applications_tracker.csv` using the Pipeline Stage vocabulary in `08_SYSTEM/commands.md`. Tracker columns: `Date, Company, Role, Role Category, Work Type, Location, Pipeline Stage, Interview_Rounds, ATS Match Score, Market Fit Score, Interview Probability, Estimated Salary Range, Recommendation, Source Assessment, Job URL, Notes`.

$ARGUMENTS
