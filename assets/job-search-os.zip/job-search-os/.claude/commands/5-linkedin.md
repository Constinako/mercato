---
description: LinkedIn audit, content strategy, or a post
---

Run the `/5-linkedin` workflow from `08_SYSTEM/commands.md`.

The system cannot see a private LinkedIn profile and should not scrape it. For audit or strategy, ask the user to export their profile as a PDF (LinkedIn "Save to PDF") or paste screenshots of every section (headline, about, experience, skills, recommendations, featured).

Ask which mode the user wants (or infer it):
- **Audit** — paste the current profile; output a scored audit with prioritized rewrites → `06_OUTPUTS/linkedin/linkedin_audit_YYYY-MM-DD.md`.
- **Strategy** — a content strategy and posting calendar → `06_OUTPUTS/linkedin/linkedin_strategy_YYYY-MM-DD.md`.
- **Post** — a specific post with hooks, final version, and an optional shorter cut → `06_OUTPUTS/linkedin/topic_YYYY-MM-DD.md`.

Agents: LinkedIn Strategist, ATS Specialist (audit keywords), Authenticity Editor (mandatory on all copy).

$ARGUMENTS
