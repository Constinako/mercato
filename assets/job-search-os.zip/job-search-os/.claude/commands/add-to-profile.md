---
description: Enrich your profile by answering a few focused questions
---

Run the `/add-to-profile` workflow from `08_SYSTEM/commands.md`.

Interview the user with focused questions to fill gaps in `01_PROFILE/profile.md`: targets, current or previous salary, target salary and floor, locations, work authorization, languages, strengths, weaknesses, what they love and hate doing, must-haves and must-nots, short and long-term goals, working style, values, interests, and anything else worth noting. For categorical questions offer options to pick from; for open questions let them type freely and give a short example; let them skip any question.

Capture salary history (what they earn now or earned most recently), not just the target. Note that the right salary target can shift by location; if they are open to multiple places, capture a target per location where it matters.

For the fit questions keep it practical: love/hate doing, must-nots and must-haves (flip each must-not into a positive must-have, e.g. "no micromanagement" becomes "high autonomy and trust"), and strengths (list even if they do not enjoy them) and weaknesses.

Write their answers into `01_PROFILE/profile.md` and, where relevant, `01_PROFILE/candidate_market_fit.md`. Keep it fast and low-friction.

$ARGUMENTS
