---
description: Log what happened after an interview, rejection, or feedback and improve the banks
---

Run the `/capture-learning` workflow from `08_SYSTEM/commands.md`.

Input: company, role, round, outcome, questions asked, the user's answers, what went well and poorly, feedback received, next step. The user can also just paste or free-type how it went and name the role.

Agents: Knowledge Manager, Interview Coach, Career Strategist.

Update: `05_INTERVIEW/central_interview_bank.md`, the role's `interview_prep.md`, `09_INSIGHTS/learning_log.md`, `09_INSIGHTS/recurring_patterns.md`, `01_PROFILE/candidate_market_fit.md`, and `03_TRACKERS/applications_tracker.csv`.

Output: lessons captured, answers improved, patterns detected, next focus, status update.

$ARGUMENTS
