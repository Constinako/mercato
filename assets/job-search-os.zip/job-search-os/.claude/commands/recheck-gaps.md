---
description: Reassess progress against your tracked gap roles
---

Run the `/recheck-gaps` workflow from `08_SYSTEM/commands.md`.

Use after the master CV or experience changes, or periodically. Compare current experience against every gap plan in `04_ASSESSMENTS/gap_roles/` to see which gaps have closed and whether any gap role is now worth applying for.

Agents: Career Strategist (gap-tracking lens), ATS Specialist.

Output: a recheck report → `09_INSIGHTS/gap_recheck_YYYY-MM-DD.md`, and update `04_ASSESSMENTS/gap_roles_strategy.md` tiers and game plan. Flag clearly, without softening, any gap that is still open.

$ARGUMENTS
