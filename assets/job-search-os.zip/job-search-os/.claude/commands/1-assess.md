---
description: Assess a job description and decide whether to apply
---

Run the `/1-assess` workflow from `08_SYSTEM/commands.md`.

Input: a job description (pasted or linked). Optional: company, role title, location, salary range, reason interested.

Agents: Career Strategist + ATS Specialist.

Output:
- Save a full narrative assessment to `04_ASSESSMENTS/assessments/company_role_assessment_YYYY-MM-DD.md`.
- Append one row to `03_TRACKERS/role_assessments.csv`.

Follow the assessment fields, the table-based file layout, CSV schema, and Shortlist_Status rules exactly as specified in `08_SYSTEM/commands.md`. Present the assessment using tables (Scores table, Compensation table with both the estimated salary and the salary-expectations guidance, Requirement Match table), not flat bullets. Do not generate a CV or cover letter. Do not write to `applications_tracker.csv`.

After presenting the assessment, offer the user three paths: apply now (`/2-apply`), pass but stay interested (`/pass-but-interested`), or move on.

$ARGUMENTS
