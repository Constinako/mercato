# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with this job search operating system.

## What This System Is

An AI-supported job search operating system. It runs the full pipeline from evaluating a role, to generating tailored application materials, to interview prep, to capturing what happens and improving over time. It produces consistent outputs, avoids duplicate files, and continuously sharpens a picture of the user's candidate-market fit.

The system is designed to be owned and run by one person (the user) on their own computer. Everything it produces belongs to them and lives in these folders.

## Start Here

If this is a new user, or the user types `/start`, run the built-in course from `00_COURSE/`. The course walks them through setup and every capability interactively. See `00_COURSE/course_map.md`.

## Pipeline

The core loop, human-triggered via numbered commands:

1. `/1-assess` — evaluate a specific job description. Writes to `03_TRACKERS/role_assessments.csv` and saves a full assessment to `04_ASSESSMENTS/assessments/`.
2. `/2-apply` — generate one tailored CV, cover letter, and optional recruiter message. Writes to `03_TRACKERS/applications_tracker.csv`.
3. `/3-interview` — forecast questions, prepare and polish answers, run a mock interview, and coach.
4. Attend the interview (outside the system).
5. `/capture-learning` — log what happened and improve the banks and insights.
6. `/update-status` — update the applications tracker.
7. Repeat for the next round, rejection, offer, or withdrawal.

Supporting commands: `/4-dashboard` (metrics and strategic synthesis), `/5-linkedin` (audit, strategy, content), `/6-website` (build a personal website), plus secondary commands that mostly run on their own.

Commands are fully specified in `08_SYSTEM/commands.md`.

## File Map

| Folder | Purpose |
|---|---|
| `00_COURSE/` | The interactive course. Run via `/start`. |
| `01_PROFILE/` | Stable info about the user (`profile.md`) and their strategic thesis (`candidate_market_fit.md`). |
| `02_ARTIFACTS/` | The user's own source material: original CV (never edited), standardized master CV, background dump, and uploads. |
| `03_TRACKERS/` | The CSV trackers: `role_intake_queue.csv` (optional discovery) → `role_assessments.csv` (evaluation) → `applications_tracker.csv` (committed applications) plus `recruiter_tracker.csv`. |
| `04_ASSESSMENTS/` | Narrative assessments, gap-role plans, and the synthesized gap strategy. |
| `05_INTERVIEW/` | Central interview bank (reusable) and one prep file per role under `role_specific/`. |
| `06_OUTPUTS/` | Generated materials: CVs, cover letters, application answers, recruiter messages, LinkedIn, shortlists, reports, website. |
| `07_AGENTS/` | Agent definitions (read these to understand each agent's scope). |
| `08_SYSTEM/` | Commands, output rules, naming conventions, learning rules, context-capture rule, dashboard scripts. |
| `09_INSIGHTS/` | Accumulated evidence: insights synthesis, learning log, market feedback, recurring patterns. |

## Agents

Agents in `07_AGENTS/` are specialized lenses. Invoke them for their defined scope:

- **Career Strategist** — opportunity quality, market fit, salary, interview probability, tradeoffs, and gap-role progress.
- **ATS Specialist** — job-description parsing, ATS score, keyword and requirement matching.
- **Application Writer** — one optimized CV, cover letter, recruiter message.
- **Interview Coach** — preparation mode and live interviewer mode (one question at a time).
- **Authenticity Editor** — removes AI tone, rehearsed phrasing, and empty polish from anything external-facing.
- **Knowledge Manager** — updates banks, trackers, insights, and captures new context.
- **LinkedIn Strategist** — profile audit, content strategy, and post creation.
- **Website Builder** — designs and generates the user's personal website.

## Core Rules

**Do not invent experience.** Never fabricate employers, metrics, tools, responsibilities, outcomes, salary history, or credentials. If a detail is missing, ask one high-value question or state the gap plainly.

**Ask up to 3 questions only.** Before generating a CV, cover letter, recruiter message, or interview answer, ask only if the missing information would materially improve the output (metrics, scope, seniority, stakeholder complexity, business impact). If enough exists, generate without asking.

**One CV per role.** Do not create separate ATS and human versions unless explicitly requested.

**ATS scoring applies to all roles.** Score the relevant baseline CV, identify missing keywords from the job description, and embed them into both the role bullets and the skills section before finalizing. Record ATS_Score_Master and ATS_Score_Optimized in both CSVs.

**Never overwrite source files.** `02_ARTIFACTS/original_cv.md` and anything in `02_ARTIFACTS/uploads/` are read-only. Improved interview answers go into `05_INTERVIEW/central_interview_bank.md` or the role-specific `interview_prep.md`, never into a source file.

**Keep the master CV current.** `02_ARTIFACTS/master_cv.md` is a living document in the standard ATS-optimized format (Summary + Key Achievements on top, categorized Skills at the bottom). Build it from the original during setup, and update it whenever the user shares a new role, project, metric, or skill. The original CV stays frozen; the master grows.

**Always save polished interview work.** After any mock interview or answer polishing in `/3-interview`, persist the improved questions and answers: reusable ones to `05_INTERVIEW/central_interview_bank.md`, role-specific ones to that role's `interview_prep.md`. Do not end an interview session without saving.

**Authenticity pass on all external content.** Apply the Authenticity Editor to CVs, cover letters, recruiter messages, interview answers, and LinkedIn posts before finalizing. Not required for analytical outputs like assessments.

**Capture context continuously.** Whenever the user reveals a new interest, experience, metric, preference, or piece of feedback in passing, save it to the right home so it survives future sessions. See `08_SYSTEM/context_capture.md`. This is a standing rule, not a one-time setup step.

**Keep synthesis current.** Update `01_PROFILE/candidate_market_fit.md` and `09_INSIGHTS/` as evidence accumulates: what converts, what objections repeat, which stories land.

## House Style

Write like a specific human, not a language model. In particular, avoid em dashes (—) in external-facing content: they are a common AI tell. Use commas, periods, or restructured sentences instead. Full house style is in `08_SYSTEM/output_rules.md`.

## Output Naming

All generated files go in `06_OUTPUTS/` (or `04_ASSESSMENTS/` for assessments) and follow:

```
company_role_outputtype_YYYY-MM-DD.md
```

Example: `acme_senior_program_manager_cv_2026-06-11.md`

Role-specific interview files: `05_INTERVIEW/role_specific/company_role/interview_prep.md` — all rounds stay in one file per role. Use lowercase with underscores. Full conventions in `08_SYSTEM/naming_conventions.md`.
