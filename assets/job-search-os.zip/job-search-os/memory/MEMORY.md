# Memory Index

This is a lightweight, persistent index of facts worth remembering across sessions: your preferences, feedback you have given the system, and ongoing context. Each line points to a short memory file in this folder.

The heavier context lives in `01_PROFILE/`, `02_ARTIFACTS/`, and `09_INSIGHTS/`. This index is for the small, durable things that should never get lost, even when a chat session forgets.

<!-- One line per memory: - [Title](file.md) — short hook -->
