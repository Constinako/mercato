# Profile

This is the single source of truth for stable information about you. The system reads this before assessing roles and writing application materials, so it stays useful even when a chat session loses memory. Fill in what you can. It gets richer over time, either as you answer questions or as details come up naturally and the system captures them for you. You can always add more with `/add-to-profile`.

## Basic Information

- Name:
- Location:
- Target locations:
- Work authorization:
- Languages (and level):

## Current Situation

- Current status (employed / searching / notice period):
- Current or most recent role:
- Reason for searching:
- Timeline / urgency:
- Financial urgency:
- Constraints (visa, relocation, start date, etc.):

## Target Roles

- Primary target roles (job titles):
- Secondary target roles:
- Roles I do not want:

## Target Companies / Industries

- Preferred industries:
- Industries I am open to:
- Industries I want to avoid:
- Company size preference:
- Company culture preference:

## Compensation

- Current or last compensation:
- Target salary:
- Minimum acceptable salary (floor):
- Bonus / equity preferences:

## Strengths

What you are particularly good at. List it even if you do not enjoy it.

-

## Concerns / Gaps

Where you are weaker, or things you want to improve. May overlap with your must-nots.

-

## What I Love / Hate Doing

Tip: turn each must-not into a positive must-have (e.g. "no micromanagement" becomes "high autonomy and trust").

- Love doing:
- Hate doing:
- Must-haves:
- Must-nots:

## Goals

- Short-term goals:
- Long-term goals:
- Areas I want to develop:

## Personal Preferences

- Preferred manager style:
- Preferred team environment:
- Preferred work style:
- Remote / hybrid / onsite preference:
- Values:
- Interests:

## Feedback I Have Received

- Recruiter feedback:
- Interview feedback:
- Manager feedback:
- Peer feedback:

## Anything Else Worth Noting

-
