# Module 3: Wrap Up

[DIRECTION: Module 3 of 5, ~5 min. Two clearly separated parts with a pause between: (A) how it is all structured, (B) tips. Then the capability recap and a warm close before the bonus. Keep chunks short. Show the actual folder path when you mention they can open files themselves.]

---

We covered a lot, and it might feel like it all lives in one long chat. It does not. It is neatly organized on your computer. 🗂️

## Part A: How it is all structured

[DIRECTION: Show the folder structure. When you say they can open files themselves, show the actual folder location on their machine, for example the absolute path to this project folder, so they can find it in Finder or their file browser.]

This is your job search operating system. It holds the instructions that run it, the context you gave me, everything we generated, your trackers, and the insights captured along the way.

- `00_COURSE` is this course.
- `01_PROFILE` is who you are and your strategy.
- `02_ARTIFACTS` is your own source material: your untouched original CV, your master CV, and anything you share.
- `03_TRACKERS` holds the CSVs behind the dashboard.
- `04_ASSESSMENTS` holds role assessments and gap plans.
- `05_INTERVIEW` is your interview banks.
- `06_OUTPUTS` is everything generated for you: CVs, cover letters, application answers, recruiter messages, LinkedIn, reports, your website.
- `07_AGENTS`, `08_SYSTEM`, and `09_INSIGHTS` are the engine, the rules, and the accumulated insight.

You can ask me to pull anything up in plain language and I will find it. Or open the folder yourself, any time, without me.

[DIRECTION: REQUIRED, do not skip. Actually output the absolute path to this project folder on their computer, in the spoken line below, so they can find it in Finder or their file browser.]
You can find all of this on your computer at: [DIRECTION: insert the absolute path to this project folder here]

Everything here, you own.

[PAUSE]
[DIRECTION: Nudge: "Want a few tips that make this work better? type next."]

## Part B: Tips and reminders

A few things worth keeping in mind.

**I am a thinking partner, not a replacement for one.** I speed things up and push your thinking, but I still need you in the loop, and I still need you to review.

**Feedback and information are fuel.** The more you tell me, the more accurate I get.

**Watch out for memory.** A single session can run out of memory. I would set up separate sessions for different jobs:

- one for application rounds
- a dedicated one for prepping a specific role's interviews
- one for tracking and updates
- one for communication and social media

That keeps each focused and easy to find later. Whatever matters gets saved to your files regardless, so nothing important is lost between sessions.

**How to call the tools.** I numbered the main commands in the order of the flow, so they are easy to remember. You can also just start typing the word and the command pops up. The main ones:

- `/1-assess`
- `/2-apply`
- `/3-interview`
- `/4-dashboard`
- `/5-linkedin`
- `/6-website` (coming up in the bonus 😉)

The rest, like `/capture-learning` or `/update-status`, are behind the scenes and mostly run on their own as you interact.

**And after you have used this for a bit, go look at your dashboard.** That is when the real value shows up.

[PAUSE]
[DIRECTION: Nudge: "Ready for a quick recap before the fun bonus? type next."]

## Quick recap

To summarize what we can do together:

1. Quickly assess jobs and focus on the ones more likely to give you an interview
2. Quickly generate application materials like a CV and cover letter, and prepare answers to application questions
3. Automatically track all your efforts
4. And more importantly, automatically capture insights, detect trends, and give you strategic direction
5. Strengthen your LinkedIn profile and presence to draw a hiring audience
6. And your own website (coming up in the bonus 😉)

I hope you found this helpful. That it saved you some time, made the process smoother, and maybe gave you a bit of clarity or the inspiration to try a new angle. 💛

[DIRECTION: That is the end of the main course. Offer the optional website bonus (Module 4) and note the sneak peek (Module 5) is after it. Then, whatever they answer, CONTINUE INTO Module 4 (`module_4_website_bonus.md`). A "no" to building a website is NOT a request to stop the course and does NOT skip Module 4: Module 4 handles both paths (yes = guided build, no = a quick sample site is still generated per its hard requirement). Do not deliver the course closing here, and do not jump to Module 5 without going through Module 4 first. The only place the closing fires early is if they decline to continue at all (want to stop the whole course), and even then Module 4's sample should already have been shown.]

That is the main course done. ✅ Up next, two optional extras: a bonus where we build your own website (Module 4), and a quick sneak peek at what is coming (Module 5). Want to build a website?

Nothing's committed here: no purchases, no publishing required. You can build and preview it now and decide about going live later, or never. And either way, I will spin up a quick sample so you can see it.
