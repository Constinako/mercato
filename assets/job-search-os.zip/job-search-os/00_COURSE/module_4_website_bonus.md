# Module 4 (Bonus): Build Your Own Website

[DIRECTION: Module 4 of 5, optional. Warm and encouraging. Build via the Website Builder agent (`07_AGENTS/website_builder.md`). Separate the process OVERVIEW from actually doing it. Ask the discovery questions ONE at a time so the user slows down and answers well. Never publish without the user's explicit signal.]

[HARD REQUIREMENT, DO NOT VIOLATE: This is a demo module, so a website is ALWAYS generated and previewed here, no matter what the user says. If they decline to build one, you still generate a quick SAMPLE site from what you already know and show them the preview. You may NOT reach the closing of this module until a website (real or sample) has been generated and previewed. Declining only means "do not do the full guided build", it never means "skip the website".]

---

As a thank you for trying this, and to help you stand out, let's build you a personal website. 🌐

You might not think you need one for your field. That is exactly what makes it powerful: it sets you apart. And it does not take long.

Unsolicited advice: put up a v1 quickly, then refine later. The v1 gives you almost all the value.

[DIRECTION: If they already said no to the website back at the end of Module 3, do NOT re-ask here. Go straight to the "No / does not want to build one" branch below and generate the sample. Only ask the question below if they have not yet answered it.]

Want to give it a go? It does not take much time, and nothing is committed: no purchases and no publishing required, you can build and preview it now and decide about going live later, or never. Even if you do not think you need one, it is one of the easiest ways to stand out. If you are in, go ahead and type **`/6-website`**.

[BRANCH: No / does not want to build one]
[DIRECTION: Non-skip, REQUIRED steps in order, do not shortcut to the closing:
  1. Say something like: "No problem, and you can do this any time later with `/6-website`. But since it takes me no time, let me spin up a quick sample from what I already know, just so you see what it can do."
  2. Walk them through the process overview below so they see how easy it is.
  3. Then actually GENERATE a quick sample website FROM WHAT YOU ALREADY KNOW about them (do not ask the discovery questions), into `06_OUTPUTS/website/`, and start the preview server, and show them the preview link. The sample must be a full example: skills / what-I-do section, a short blog with a couple of starter posts, and a downloadable styled CV PDF, just like a real build.
  4. Only after the sample has been generated and previewed, go to the closing.
You must not skip step 3. Do not end this module without having shown a website.]

[BRANCH: Yes / types `/6-website`]

## First, the overview

Here is how this will go:

1. I ask you a few questions (one at a time)
2. I generate a first version
3. You review it and give feedback
4. If you want to go live: buy a domain, set up GitHub, publish
5. Your new link gets added to your CV and future application materials

The whole thing can be as little as 10 minutes, on average about 30, depending on how much input you want to give. Going live afterward is quick.

[PAUSE]
[DIRECTION: Nudge: "Ready for the first question? type next." Then ask the four discovery questions ONE at a time, pausing after each. Do not batch them.]

## Now, the questions (one at a time)

[DIRECTION: Question 1. Present the "what is this site for" part as a MULTI-SELECT / checkbox-style question (they can pick more than one), with these options plus an "other / type your own": standing out as a candidate, freelance work, speaking, selling something, portfolio. Then ask the follow-up as free text. Wait.]
**First: what is this site for?** Pick any that apply (stand out as a candidate, freelance work, speaking, selling something, portfolio, or your own). And what roles or clients do you want it to attract?

[PAUSE]

[DIRECTION: Question 2. Ask and wait. Prompt explicitly for images and media.]
**Second: your content.** Tell me about any projects, professional or personal, that you would want to feature. Paste details, and importantly, share any images, screenshots, or media you have for them (attach them here). Visuals make a personal site.

[DIRECTION: If they mention or have an existing personal website (Wix, WordPress, Notion, a live URL, etc.), ask them to share the link. Then thoroughly read through ALL of its pages and automatically extract the relevant content for reuse, so they do not have to copy-paste anything. For images: slow down and actually check whether you can access and pull the visuals; do not assume it worked. If you cannot reliably extract an image, say so and ask them to attach it directly rather than claiming it is there. Building a fresh one here is still worth it, so they can compare.]

[PAUSE]

[DIRECTION: Question 3, styling and inspiration, kept as ONE question separate from the existing-site topic. Ask and wait.]
**Third: the look and feel.** Any styling preferences, colors, tone (minimal, bold, warm, technical)? And is there any website you like the look of? It does not have to be a personal site, just something for design inspiration. If you have nothing in mind, no worries, I will choose a clean, modern style that fits your field.

[PAUSE]

[DIRECTION: Question 4, the blog. ALWAYS ask this, do not skip it. Ask and wait.]
**Fourth: do you want a blog?** It is a nice way to show your thinking and stay visible. And if you do not have your own posts yet, no problem, I can draft a few starter posts for you to publish, based on what we have talked about.

[PAUSE]

## Build and preview

[DIRECTION: Generate a clean, responsive, well-styled static site into `06_OUTPUTS/website/`, following `07_AGENTS/website_builder.md`. If they gave no styling preference, do NOT ship something plain: infer a tasteful, modern look from their industry and career. Always include a skills / what-I-do section (even without selected works or a freelance goal), and always include a downloadable styled CV PDF named `CV_FirstnameLastname.pdf` that matches the site's look. Use their real content and any images they shared. Then start a local preview and give them the link:
python3 -m http.server 8787 --directory 06_OUTPUTS/website
Open http://localhost:8787. Gather feedback and iterate.]

Here is your site. A couple of things worth knowing: it is built to be **responsive across all screen sizes**, so it looks good on a phone, a tablet, and a desktop. And it includes a **downloadable CV** styled to match the site. Handy to share, though for actual applications you should still generate a tailored CV per role to maximize your interview chances.

[PAUSE]
[DIRECTION: Nudge: "Happy with it, or want changes? When it's good, we can talk about going live."]

## Going live (only when they say so)

[DIRECTION: Publishing happens only on the user's explicit signal. Deliver this in short chunks.]

Ready to publish now, or keep it as a private preview for later?

If you want to go live:
- Buy a domain (Porkbun is a solid, cheap option, about 10 euros a year)
- Set up a free GitHub account
- I will walk you through publishing with GitHub Pages and pointing your domain

I will not buy anything or create accounts on your behalf. That part is on you.

Setting up the accounts and publishing takes about 5 to 10 minutes total. And once it is live, you can always update it easily: just call `/6-website` and tell me what you want to change, and I will update the site for you.

[DIRECTION: When walking them through GitHub Pages: create a repo, push the contents of `06_OUTPUTS/website/`, enable Pages on the main branch. Add a `CNAME` file with their domain and set the DNS records at the registrar. IMPORTANT: in the repo's Settings > Pages, once the custom domain is set and DNS has propagated, tick the "Enforce HTTPS" checkbox. It is often greyed out at first and only becomes available after the domain verifies, so tell them to come back and enable it, or the site can load insecurely or fail. This was a real gotcha.]

[BRANCH: Built but not published]
Great job building this. I saved it, so you can publish any time you choose. Or never. It is yours either way.

[BRANCH: Published]
Your site is live. 🎉 Now do not forget to share that link.

[DIRECTION: Either way, remind them to add the link to their CV, LinkedIn, relevant social profiles, and to send it to recruiters they are already talking to, especially if the site shows projects not on their CV.]

[PAUSE]

## Closing

[GATE: Before delivering anything in this closing, confirm a website (real or sample) was actually generated and previewed earlier in this module. If it was not, go back and do that first. Do not reach this closing having skipped the website.]

[DIRECTION: Offer the final Module 5 sneak peek. Wait. IMPORTANT: if the user declines, or if they declined the website at the top, deliver the full course closing before ending (thank them for going through the course, request feedback specific to their field or region at mariecmuniz@gmail.com, and the "take a nap, get fresh air, go for a dance" send-off from `module_5_advanced_preview.md`). The course must never end without that closing.]

That is the bonus done. ✅ One last quick thing: a sneak peek at what is coming next. Want to see it?
