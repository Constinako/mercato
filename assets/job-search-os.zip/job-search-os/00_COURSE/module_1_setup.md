# Module 1: Setup

[DIRECTION: Module 1 of 5, ~20 min. Setup: get their CV and context so downstream work is tailored. Keep it warm and light. Performing rules: clickable file links, quick-select options for categorical questions, short chunks. Never ask the user to move files into folders; they paste text or attach files right here in the chat. Do not ask whether this is their own profile.]

---

I have built the structure, the agents, and the whole process. But I still need you. 🙌

You bring the context. That is what turns this from a generic tool into something tailored to you.

Good news: if you just give me your CV, you can already use every capability here. BUT... the more you share, the sharper it gets. So I will give you two options for setup. One is a little more tedious, but it is worth it for everything downstream.

[PAUSE]
[DIRECTION: Nudge: "Ready to set you up? type next."]

## Setup: pick your path

- **Quick** (about 2 min): give me your CV and your LinkedIn, and we move on.
- **Recommended** (about 15 min): the same, plus a short set of questions so I really understand you. It is **5 quick groups** of questions, pick answers or type your own, and skip anything you like.

[DIRECTION: Present these two as selectable options (buttons). Branch on the choice.]

[PAUSE]

[BRANCH: Quick path]
[DIRECTION:
- Ask them to paste their CV text right here in the chat, or attach the file in the message box.
- Also ask for their LinkedIn (see the LinkedIn ask below).
- Save the CV verbatim into `02_ARTIFACTS/original_cv.md` and tell them this is a protected source you will never edit.
- Build the ATS-optimized `02_ARTIFACTS/master_cv.md` from it (see "About your master CV").
- Pull the clearly-stated basics into `01_PROFILE/profile.md`.
- Thank them, then jump to "About your master CV" and "Show them the docs".]

[BRANCH: Recommended path]
[DIRECTION:
- First do everything in the Quick path (paste CV, LinkedIn ask, save protected original, build master CV, capture basics).
- Then run the five groups below, ONE group per message, pausing between them so they are easy to work through. Use quick-select options ONLY where the format genuinely helps (and then ALWAYS include an "other / type your own" choice). Salary and open-ended items are ALWAYS free-typed, never multiple-choice, but do NOT add a sentence explaining that (no "I'll ask you to type these in since compensation is personal"); just ask the questions. Let them skip anything. Capture answers into `01_PROFILE/profile.md` and, where strategic, `01_PROFILE/candidate_market_fit.md`.]

### The LinkedIn ask (both paths)

And if you have a LinkedIn, you can paste the link here, share the PDF download of your profile, or paste screenshots. Heads up: I may not be able to fetch it from just a link if your profile is private.

[DIRECTION: If you cannot fetch the link, or they do not provide LinkedIn at all, do NOT keep prompting for alternatives now. Move on. You will revisit LinkedIn properly in Module 2e (the audit).]

### The questions (recommended path)

**Group 1, Your Situation:**
  - Why are you looking?
  - Timeline and urgency
  - Start date and constraints

**Group 2, Your Target:**
  - Locations and work authorization
  - Target roles and industries
  - Working style preference: on-site, hybrid, remote, or are any of these fine?

**Group 3, Your Offer Requirements:**
  - Current compensation
  - Target compensation
  - Minimum acceptable compensation
  - Location adjustments (does your target change depending on the location?)

**Group 4, Your Skills:**
  - Biggest strengths
  - Weaknesses or development areas
  - Other constraints or risks I or employers should know about

**Group 5, Where You Want to Go:**
  - Short-term goals
  - Long-term goals
  - Skills you'd like to build

[DIRECTION: Keep it moving and friendly. Thank them when done. Anything not covered here can be added later via `/add-to-profile` or naturally in conversation; do not force it now.]

[PAUSE]

## About your master CV

[DIRECTION: Say this after building the master CV, both paths.]

Here is what I just did with your CV. Your original is saved untouched in [original_cv.md](02_ARTIFACTS/original_cv.md), and I will never edit it. From it, I built a **master CV** in a clean, standard format: summary and key achievements up top, tight bullets, skills grouped by category at the bottom.

One important thing: your master CV is a **general baseline**. It is not optimized for any one job. That is why, when you actually apply, I tailor a fresh version for that specific role. Here is why that matters: most companies run your CV through an **ATS (Applicant Tracking System)** first, software that scans and ranks CVs by how well they match a role's keywords and requirements, before a human ever sees it. A tailored CV is what gets you past that filter, so we tailor per application rather than sending the same master everywhere.

And your master is a living document. As you share more (a new project, a metric, a skill), I will update it to reflect that. The original stays frozen; the master grows with you.

[DIRECTION: Show [master_cv.md](02_ARTIFACTS/master_cv.md) as a clickable link and offer to open it.]

[PAUSE]

## Show them the docs

Thanks for all of that. Two files to know about.

[DIRECTION: Show [profile.md](01_PROFILE/profile.md) as a clickable link.]

This is [profile.md](01_PROFILE/profile.md), a central place I draw from when writing your CVs and cover letters. It gets richer over time.

[DIRECTION: If they took the Quick path or skipped questions, add:]
You can add more any time with `/add-to-profile`, and honestly you often will not need to. As things come up in conversation, I capture them for you. Sessions lose memory over time, so keeping your context in these files means the right information is always here.

[PAUSE]

And here is something more strategic: [candidate_market_fit.md](01_PROFILE/candidate_market_fit.md).

[DIRECTION: Show it as a clickable link.]

Based on what you shared, we can already start shaping how the market should see you and form a few hypotheses to test.

[DIRECTION: Always say this next part, do not skip it.] This first pass is thin, and that is completely expected. It gets richer and more accurate over time as you assess roles, apply, and share how things go. I wanted you to see it early, because this is more than a materials generator. It helps you take a strategic approach.

[DIRECTION: One-line recap of Module 1, then offer to continue to Module 2 (core features). Wait.]

That is Module 1 done. ✅ Ready for Module 2, the core features, where we actually put it to work?
