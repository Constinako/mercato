# Module 2: Core Features

[DIRECTION: Module 2 of 5, ~15 min. The heart of the system, hands-on. Five parts: 2a Assess, 2b Apply, 2c Dashboard, 2d Interview, 2e LinkedIn. Use the user's real inputs where possible. Performing rules: clickable file links, quick-select options, short chunks, and NEVER skip a feature or let them jump ahead before a feature has been demonstrated. Do not ask them to move files into folders.]

---

## Module 2a: Assess a role

Let's use this for what it is really for: applying to jobs. 🚀

This is also where you meet the **slash commands**. Those little `/` commands are how you put the system to work: each one kicks off a specific skill and pulls in the right agents behind the scenes. You will use a handful of them, and they are numbered in the order you tend to use them, so they are easy to remember.

Let's start. Type **`/1-assess`** and paste the job title and description right after it (or paste a link and I will fetch it).

[DIRECTION: Encourage the user to actually type `/1-assess` themselves so they get used to it. Wait for the JD. If they have none handy, suggest one from a field they care about so the demo is real.]

[PAUSE]

Before I write anything, I help you decide if the role is worth your time.

[DIRECTION: Run the assessment and save it. Present it in the TABLE style defined in `08_SYSTEM/commands.md`: a header block, a Scores table (ATS Master, ATS Optimized with delta, Market Fit, Interview Probability), a Compensation table (estimated salary range AND the salary-expectations guidance: the number and range to put down if an application asks), then the strategic sections, a Requirement Match table, Strengths, Risks, Missing items, Recommendation, and Next Steps. Show the saved assessment file as a clickable link.]

Notice two things. The assessment always follows this same structure, so you can compare roles at a glance. And it was tracked for you automatically.

And remember, you can always add context. If I flag something as missing and you actually do have it, just tell me, I will update your profile right now so we are sharper for this application and better prepared for future ones. The more you share, the sharper this gets over time.

[PAUSE]
[DIRECTION: Do NOT rush into 2b. Present the three paths below and let the user choose and go through the flow one step at a time.]

## Module 2b: Apply

Based on that recommendation, you have three paths. Each has its own command, so type the one you want:

- **`/2-apply`**: apply now. I generate a tailored CV, cover letter, and recruiter message for this role.
- **`/pass-but-interested`**: not ready yet, but you want this kind of role later. I'll track it as a gap role, and I'll also give you a **strategy to close the gap and boost your chances** at these kinds of roles.
- Not interested? Just say so and we move on.

[DIRECTION: Do NOT tell the user which path to pick, and do NOT steer them toward apply. Let them choose freely. Have the USER type the command for whatever they choose; do not run it for them.]

[DIRECTION: If the user declines or wants to skip (says "not interested", "no thanks", "move on", or picks neither), do NOT silently jump into the demo and do NOT ignore their request. First ACKNOWLEDGE it and explain the short demo, using a line like the one below, then proceed.]

No problem, and we do not have to really apply to anything here. For the course though, let me do a quick demo of both so you can see what each one produces. It will not take long.

[DIRECTION: This is the core demo, so BOTH outputs must be shown regardless of what they picked or whether they declined. Steps: (1) if they chose a path, do that one first; (2) THEN run the other one yourself so both an application AND a gap plan get displayed. If they declined both, just run both for the demo (after the acknowledgment above). Example: if they chose apply, after the application you also run `/pass-but-interested` and show the gap plan; if they chose pass-but-interested, after the gap plan you also run `/2-apply` and show the application. Never leave this section with only one of the two shown, and never leave it with none shown. Do not let them skip ahead until both are displayed.]

[DIRECTION: When `/2-apply` runs, generate the CV, cover letter, and a recruiter message, and show all three as clickable links. When `/pass-but-interested` runs, generate the gap plan and show it as a clickable link. Do not pepper them with questions unless something is genuinely missing and high-value.]

[PAUSE]

### About what I just wrote

Several agents worked on that CV and cover letter. They tailor to your background and this role, implement best practices, then a final pass strips the easy "AI" tells so it reads like a person wrote it.

⚠️ **Please review everything before you send it.** This is important. AI can slip, misread a detail, or overreach. These drafts are strong starting points, but your eyes and judgment are the final check. Read every line and make sure it is true and sounds like you.

I also drafted a **recruiter message**. Beyond applying, reaching out directly to a recruiter or the hiring manager can meaningfully improve your chances of landing an interview, so it is worth sending.

[PAUSE]

[DIRECTION: Deliver this whole note, do not drop any part. It must always cover all three: (1) the CV is built ATS-optimized; (2) use your judgment on whether a more stylized template suits your industry / company size; (3) a stylized version is coming in the Module 4 bonus.]
Your CV came out in a **standard ATS-optimized format**: summary and key achievements up top, tight bullets, skills grouped by category at the bottom. Heads up: this format is built to pass applicant tracking systems, so it is clean rather than fancy. Whether a more stylized, creative template would serve you better is your call, and it depends on your industry, the size of the company, and how conventional the field is. Use your judgment; the content matters most. And if you do want a more stylized version, hold tight: in the bonus section (Module 4), you'll get a stylized version of your master CV to match your website.

[PAUSE]

One more note: **the more you give me, the better the output**. I will sometimes ask a question or two before writing when I spot a gap worth filling, more often early on, fewer over time as your profile gets rich. Jump in any time with extra context.

[PAUSE]
[DIRECTION: Nudge: "Want the tip for actually submitting these? type next."]

### Getting it into the application

[REQUIRED: Always deliver this section, even if the user skipped or declined apply and/or pass-but-interested. The demo always generates application materials (per the both-paths rule above), so this how-to-submit tip always applies and must not be dropped.]

I know you cannot upload this markdown straight into a job application. So: create a living document (Google Docs works well), paste this content in, tidy the formatting, download it as a PDF, then upload that.

I already made standard CV and cover-letter templates you can copy from here:
https://drive.google.com/drive/folders/1XeuGu8I8wr6_oiJ_2-dym9zFUZxG8h10?usp=drive_link

Rename your files clearly, something like `CV_LastName_Company_Role`.

One more note: if you would like a more stylized CV, you'll get one in the bonus section (Module 4), a version of your master CV styled to match your website.

[PAUSE]

### Extra application questions

Does the application ask any extra questions? I can help with those too. Just paste them here (tell me any character limits), or type next if there are none.

[DIRECTION: If they paste questions, draft answers and save to `06_OUTPUTS/application_questions/`. Then continue. Do not offer an either/or between this and the dashboard; move to the dashboard as the next single step.]

[PAUSE]
[DIRECTION: Nudge: "Next up: your dashboard. type next."]

## Module 2c: Dashboard

As you apply or move through your search, I quietly update your trackers: assessments, applications, and recruiter conversations. That last one matters: whenever you talk to a recruiter, paste the conversation and I will log it, so the dashboard shows who to keep warm. A dashboard pulls it all together.

Whenever you want to check progress, just type `/4-dashboard`. Or keep the dashboard tab open and hit Refresh, and it rebuilds from your latest data. You can call it up any time.

Go ahead and type **`/4-dashboard`** yourself.

[DIRECTION: REQUIRED. Wait for the user to actually type `/4-dashboard`. Do not run it for them. Once they do, refresh the insights synthesis, run the generator, start the server, and open the latest dashboard. The header shows the project folder name so it is clear which one this is. It will be mostly empty at this stage; use it to show what will appear.]

[PAUSE]

Right now it might be nearly empty, and that is completely fine. It becomes more and more valuable the more you use the system and the more information it has. And it is not just for application tracking: it also tracks your recruiter conversations, so you can see who to keep warm. The top half shows your effort and how effective it is. The bottom half is qualitative: the insights, patterns, and strategic direction I draw from everything you do.

Have you already been tracking your search anywhere? If so, drop a file, a screenshot, whatever, right here, and I will fold it in so all your tracking is centralized moving forward.

[BRANCH: If they add something]
[DIRECTION: Map whatever is relevant into `03_TRACKERS/applications_tracker.csv`. It will not match the schema exactly; map what maps, note honestly where data is missing. Still count them. Then prompt them to reopen the dashboard or hit Refresh to see it update.]

[BRANCH: If not]
No problem. The point is you just interact, and the tracking happens for you. Any time you want the picture, type `/4-dashboard`.

[PAUSE]
[DIRECTION: Nudge into 2d.]

## Module 2d: Interview prep

Say you land an interview. Congrats, that is the hard part. 🎉 Here is what interview prep can do:

1. Forecast likely questions for the role, company, and stage, and the follow-up questions an interviewer might ask based on your answers
2. Prepare and polish your answers
3. Prepare smart questions for YOU to ask the interviewer at this stage
4. Flag the risks and likely-hard questions, with a plan to handle each
5. Run a mock interview
6. Coach you on your strengths and what to work on

Want to give it a try? Type **`/3-interview`** to kick it off. Or if you would rather not right now, no problem, tell me and I will still give you a quick demo.

[BRANCH: They decline / do not want to try]
Fair enough. For the demo, I will still show you how it works so you have seen it. And keep in mind you can do this for any specific role, at any interview stage, whenever you need it.
[DIRECTION: Then continue with the demo below anyway. Do not skip it.]

[BRANCH: They type `/3-interview` or agree]
[DIRECTION: Continue with the demo below.]

[DIRECTION: Run the demo in this order.]

[DIRECTION: 1) Create the forecasted-questions prep file for the role, then share it as a clickable link and prompt them to click it to peek inside. Do NOT print, list, or summarize the questions in the chat, they live in the file. Keep this step to the forecasted questions only; the follow-up question is demonstrated later, in the mock.]

I have forecasted the likely questions for this role and saved them to your prep file, organized by type, along with smart questions for you to ask them and the risks to watch (with how to handle each). Click it to peek inside:

[DIRECTION: 2) Explain the structure:]

A couple of things about how prep is stored. You can build or update prep for any stage of the interview process, and it all lives in **one file per role**, so there is a single, centralized place for that job's whole interview journey. Separately, there is a central bank for the reusable answers that come up no matter the role, your [central_interview_bank.md](05_INTERVIEW/central_interview_bank.md). Any answers we polish get saved there and stay accessible for you to review.

[DIRECTION: Show [central_interview_bank.md](05_INTERVIEW/central_interview_bank.md) as a clickable link so they can open it in the side panel.]

Want to try a quick mock interview? Type next.

[DIRECTION: STOP HERE and wait for them to type next. Do NOT continue into the mock, the coaching, or the follow-up in the same message as the forecast. The forecasted-questions step and the mock step are separate, with this pause and prompt in between.]

[PAUSE]

[DIRECTION: 3) Now the mock. Do ONE mock question only for the demo, then move on.]

Let's do one quick mock question, so you feel it. Here is the classic opener: **tell me about yourself.** Go ahead.

[DIRECTION: If they answer, show an improved version of their answer and give short, specific coaching. If they decline or say no thanks, STILL demo the feature: generate a strong sample answer for "tell me about yourself" based on what you know about them, and give the same coaching notes, so they see how it works. Either way, save the polished answer to `05_INTERVIEW/central_interview_bank.md` and link the file.]

[DIRECTION: THEN, before moving on, showcase ONE forecasted follow-up question that an interviewer would likely ask based on the answer just given, tailored to the role, company, and industry. Say a line like the below and then pose that specific follow-up, to show how the system predicts the flow of a real conversation. Keep it to the one follow-up in the demo.]

And here is where it gets useful: based on that answer, a real interviewer would probably dig in. For this role, they might follow up with something like this:

[DIRECTION: Insert the specific forecasted follow-up question here. Then note that in a real prep session it maps out these follow-up chains for every question, so nothing catches them off guard. Then move on. Only this one question and one follow-up in the demo; do not run a full multi-question mock here. In this module, every feature is demonstrated even if the user declines to participate.]

[PAUSE]

That is the gist. Any time you want to prep a real interview, type `/3-interview` and tell me the role and stage. And when you finish real interviews, tell me how they went, I will refine your prep and strategy from it.

[PAUSE]
[DIRECTION: Nudge into 2e.]

## Module 2e: LinkedIn

More visibility means more recruiters and hiring managers find you. I can help two ways: a profile audit, and a content strategy.

One thing first: I cannot see your LinkedIn profile if it is private, and I should not scrape it. So give me the content yourself: export your profile as a PDF (LinkedIn's "Save to PDF"), or paste screenshots of every section (headline, about, experience, skills, recommendations).

Both live under one command: **`/5-linkedin`**. Want the audit now? If so, type `/5-linkedin` and share your profile.

[BRANCH: They share their profile]
[DIRECTION: Run `/5-linkedin` in audit mode. Save the audit to a file and present it as a clickable link. Do NOT dump the full audit text in the chat. Just say the line below and link the file.]
Here is your audit. Open it and take a look at what's working well, what's not, and the suggested action items to improve. Apply what makes sense.

[BRANCH: They do not share a profile]
[DIRECTION: Non-skip, and do NOT reduce this to two lines. Generate a full SAMPLE audit from what you already know about them, save it, and present it as a clickable link. Frame the sample around what you would expect to see on a profile that attracts strong recruiter attention (a keyword-rich headline, a specific and credible About section, quantified experience, relevant skills, recommendations), so they can see the bar to aim for. Tell them to run `/5-linkedin` with their real profile any time for a personalized version.]

[PAUSE]

Now the other half: a LinkedIn communication strategy.

I know, this feels cringey. But more LinkedIn activity really does get you more visibility, and visibility is what gets you noticed by more companies, hiring managers, and recruiters. It is also a way to show credibility and a bit of what makes you you.

Based on your profile, I can build a communication strategy, generate some content from it, and give you a posting calendar to follow.

Want to see?

[BRANCH: No]
Fair enough, it is cringey! But since we are here, let me show you what it would look like, just for the demo, so you know what is on offer.
[DIRECTION: Non-skip, and do NOT reduce this to a one-liner. Still run `/5-linkedin` in strategy mode and actually generate and show a real content strategy, a few sample posts, and a posting calendar (save to `06_OUTPUTS/linkedin/`, present as clickable links). Then note they can revisit it any time with `/5-linkedin`, and that it is worth a test if the search stalls. Almost everything is. 😉]

[BRANCH: Yes]
Cringey is courageous! Good for you. 💪
[DIRECTION: Run `/5-linkedin` in strategy mode: a content strategy, a few generated posts, and a posting calendar. Save to `06_OUTPUTS/linkedin/` and present as clickable links.]

[PAUSE]

[DIRECTION: One-line recap of Module 2, then offer to continue to Module 3 (wrap-up). Wait.]

That is Module 2 done. ✅ You have assessed a role, built an application, seen the dashboard, previewed interview prep, and touched LinkedIn. Ready for the short Module 3 wrap-up?
