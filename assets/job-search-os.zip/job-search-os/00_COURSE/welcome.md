# Welcome

[DIRECTION: The opening of `/start`. Warm and encouraging. Read `course_map.md` first for the performing rules. Do the first-run check SILENTLY: do NOT narrate it at all. Never say anything about placeholders, empty files, "your first time here", or "we'll go through setup together". Do not ask whether this is their own profile; assume it is theirs or they have permission. Just begin with the welcome line below. Deliver the welcome, the value overview, and the course outline, pausing where marked. Keep chunks short. Keep the emojis. If you can set or suggest a session name, suggest naming this session "Job Search Operating System".]

---

Welcome to your Job Search Operating System! 🎉 First, take a second to acknowledge that you're pushing through in this job market. It's not easy, and showing up for it counts.

Whenever you're ready, type next to keep going.

[PAUSE]

I built this Job Search Operating System for three reasons: to save myself time, to test strategies until I found ones that actually worked, and to learn where AI genuinely helps in a job search and where it does not.

After thoroughly using it and testing it myself, I wanted to pass it on and hopefully save you a few headaches. 🙂

[PAUSE]
[DIRECTION: Continue into the value list.]

Here is what it can do for you.

**📄 Application support**
- Assess roles so you spend energy where it pays off
- Generate ATS-friendly, tailored CVs and cover letters
- Track everything automatically, with a custom dashboard

**🧭 Insights and direction**
- Capture insights continuously as you go
- Build a clear picture of your candidate-market fit
- Spot the gaps worth closing so you unlock more opportunities

**🎤 Interview prep**
- Forecast likely questions for each stage
- Build a central bank plus role-specific prep
- Run mock interviews and get real coaching

**📣 Visibility and outreach**
- Audit your LinkedIn and tell you what to change
- Create LinkedIn content that gets you seen
- Track recruiter conversations and draft your outreach

**🌐 Bonus**
- Build your own personal website to stand out

[PAUSE]
[DIRECTION: Nudge: "Ready to see how the course is laid out? type next."]

## One quick setup tip before we start

Two small things make this smoother:

- Pick a permission mode: **accept-edits** (you approve edits before they happen) or **auto** (I create and update your files without stopping to ask each time). In the terminal, press **Shift+Tab** to cycle modes. In the desktop app, use the permission-mode toggle near the input box.
- For the model, **Sonnet** is a great, cost-effective default. If you have access to **Opus**, it gives the richest results, but Sonnet handles all of this well.

[PAUSE]

## What this course covers

We will go at your pace, and I will pause often. It is 5 short modules, and this is hands-on: we actually use the system as we go.

- **Module 1. Setup** (~5 to 20 min, depending on quick vs recommended): give me your CV and a bit of context so everything downstream is tailored to you.
- **Module 2. Core features** (~15 min): the heart of it, by doing it together.
  - Assess a role
  - Generate your application (CV + cover letter)
  - Dashboard
  - Interview prep
  - LinkedIn strategy
- **Module 3. Wrap-up** (~5 min): how it is all structured, plus tips worth knowing.
- **Module 4. Bonus (optional)** (~10 to 30 min): build your own website to stand out.
- **Module 5. Sneak peek** (3 min): advanced features coming soon.

All in, the core is about **40 minutes**, plus another **10 to 30** if you do the optional website. It flexes with how much context you give me, the more you share, the more you get out of it.

[DIRECTION: Do NOT present options or a yes/no here. Just a plain continue nudge, so it does not compete with the Quick vs Recommended choice that opens Module 1.]

Ready to start? Type next and we will set you up.

[PAUSE]

[DIRECTION: When they continue, go into `module_1_setup.md`. The first choice they see should be the Quick vs Recommended setup path, and that is the ONLY option menu at setup.]
