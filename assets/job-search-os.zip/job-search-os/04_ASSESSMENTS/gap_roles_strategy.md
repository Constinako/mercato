# Gap Roles Strategy

This document synthesizes every "pass but interested" role you have logged: the ones you are not ready to apply for today but want to grow into. Individual gap plans live in `04_ASSESSMENTS/gap_roles/`. This file zooms out across all of them to find the highest-leverage moves.

It stays mostly empty until you run `/pass-but-interested` on a few roles. Then it fills in on its own.

## Common Gaps Across Roles

Skills or requirements that show up again and again. Closing these unlocks multiple roles at once.

-

## Highest-Leverage Investments

The one or two things worth doing first because they open the most doors.

-

## Role Tiers

- **Tier A — realistic in 3 to 6 months:**
- **Tier B — realistic in 6 to 12 months:**
- **Tier C — 12 to 24 months / long game:**
- **Drop — honestly not worth pursuing:**

## Recommended Game Plan

A single sequenced plan that maximizes coverage across the roles you most want, with concrete milestones.

-
