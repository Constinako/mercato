# Master CV

This is your working master CV: a clean, ATS-friendly, standardized version the system builds from your original CV during setup. Every tailored CV under `06_OUTPUTS/cvs/` starts from this.

The system keeps this in a consistent structure so tailoring is fast and predictable. It updates as you gain new experience, projects, or skills. Your untouched original lives in `02_ARTIFACTS/original_cv.md`.

## Contact

- Name:
- Location:
- Email:
- Phone:
- LinkedIn:
- Portfolio / website:

## Summary

Three sentences max: years and type of experience, key roles, current focus. No aspirational language.

## Key Achievements

Three to five of your strongest, most quantified wins, pulled up top so they are seen first.

-

## Experience

### [Role] — [Company] · [Location] · [Dates]

- Bullet: strong action verb, a metric even if approximate, under 20 words.
- Max 5 bullets for the two most recent roles, max 3 for earlier ones.

## Education

-

## Certifications / Projects

-

## Skills

Kept at the bottom, grouped into categories, keyword-rich and easy for ATS to parse.

- **[Category, e.g. Tools]:**
- **[Category, e.g. Domains]:**
- **[Category, e.g. Languages]:**
