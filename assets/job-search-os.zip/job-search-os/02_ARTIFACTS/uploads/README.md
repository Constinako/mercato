# Uploads

Drop any supporting material here: portfolio pieces, project decks, reference letters, case studies, screenshots of metrics, a WordPress or Wix export, anything that proves what you have done.

Tell the system what you dropped in and it will pull the relevant details into your profile, background dump, CVs, and interview prep. Files here are treated as source material and are never overwritten.
