# Original CV (Source, Do Not Overwrite)

Paste the full, current version of your CV here exactly as it is today, or drop the file into `02_ARTIFACTS/uploads/` and tell the system to import it.

This file is a protected source. The system never edits it. It stays as your untouched baseline so you always have the original to fall back on. All tailoring happens in generated files under `06_OUTPUTS/`, never here.

<!-- Paste your CV below this line -->
