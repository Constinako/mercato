# Background Dump

A freeform home for anything about you that does not fit neatly into the CV or profile yet: detailed project stories, metrics, context about past roles, personal details you have shared in passing, half-formed thoughts. Nothing here has to be polished.

The system draws on this when writing CVs, cover letters, and interview answers, and it adds to this file automatically whenever you mention something worth keeping. The more that lives here, the more specific and credible your materials become.

<!-- Dump anything relevant below. Rough notes are fine. -->
