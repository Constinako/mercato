# Job Search OS

An AI-supported job search operating system that runs in Claude Code. It assesses roles, writes tailored CVs and cover letters, preps you for interviews, tracks everything automatically, and turns your search into strategic direction instead of guesswork.

## Getting started

1. Install Claude Code (see claude.com/claude-code).
2. Open this folder in Claude Code.
3. Type `/start`.

That launches the built-in course, which walks you through setup and everything the system can do. You do not need to read any of the files first. Just type `/start` and follow along.

## What it does

- **Assess** roles so you spend effort where it counts (`/1-assess`)
- **Apply** with an ATS-friendly, tailored CV and cover letter (`/2-apply`)
- **Prep** for interviews with forecasted questions, a mock interview, and coaching (`/3-interview`)
- **Track** every application, assessment, and recruiter automatically, with a live dashboard (`/4-dashboard`)
- **Grow visibility** with a LinkedIn audit, strategy, and content (`/5-linkedin`)
- **Stand out** with your own personal website (`/6-website`)

Everything it generates is saved in these folders and belongs to you, on your computer.

## The short version of the map

- `00_COURSE/`: the guided course. Start here.
- `01_PROFILE/`: who you are and your strategy.
- `02_ARTIFACTS/`: your CV and source material.
- `03_TRACKERS/`: the CSV trackers behind the dashboard.
- `04_ASSESSMENTS/`: role assessments and gap plans.
- `05_INTERVIEW/`: your interview banks.
- `06_OUTPUTS/`: everything generated for you.
- `07_AGENTS/`, `08_SYSTEM/`, `09_INSIGHTS/`: the engine, rules, and accumulated insight.

Type `/start` when you are ready.
