# Central Interview Bank

Your reusable, role-agnostic interview answers. These are the questions that come up no matter what job you interview for. Prepare them once, polish them over time, and reuse them everywhere.

Every time you run `/3-interview` and polish an answer that is generally reusable, it gets saved here. Answers specific to one company or role go into that role's file under `05_INTERVIEW/role_specific/`.

Aim to build a solid set of stories you know cold. Preparation and practice are two different activities: prepare the answers here, then practice saying them out loud closer to the day.

---

## Tell me about yourself

**Answer:**

**Notes:**

---

## Why are you looking / why leave your current role?

**Answer:**

**Notes:**

---

## Greatest strength

**Answer:**

**Notes:**

---

## Greatest weakness

**Answer:**

**Notes:**

---

## Tell me about a time you led / drove impact

**Answer (STAR):**

**Notes:**

---

## Tell me about a conflict or difficult stakeholder

**Answer (STAR):**

**Notes:**

---

## Where do you see yourself / what are you looking for next?

**Answer:**

**Notes:**

---

## Questions I ask the interviewer

-

<!-- Add new reusable questions and answers below as they come up. -->
