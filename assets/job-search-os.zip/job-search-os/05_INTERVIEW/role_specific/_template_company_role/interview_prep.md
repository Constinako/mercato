# Interview Prep — [Company] — [Role]

One file per role. Every round for this role lives here: forecasted questions, polished answers, coaching feedback, and anything you remember after the real interview. Do not create separate files per round. Copy this template into `05_INTERVIEW/role_specific/company_role/interview_prep.md` when you start prepping a new role (the `/3-interview` command does this for you).

## Role Context

- Company:
- Role:
- Job description link:
- What matters to them (mission, product, signals from the JD):
- Salary context:

## Interviewers

- Round 1:
- Round 2:
- Later rounds:

---

## Round 1 — [type, date]

### Forecasted questions

-

### Polished answers

**Q:**
**A:**

### Coaching feedback

- What worked:
- What to improve:
- Practical next steps:

### Remembered from the actual interview

Questions they actually asked, your read on how it went, any feedback received. Capture this right after, while it is fresh (or run `/capture-learning`).

-

---

## Round 2 — [type, date]

<!-- Same structure. Add rounds as they come. -->
