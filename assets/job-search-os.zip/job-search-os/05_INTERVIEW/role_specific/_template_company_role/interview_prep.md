# Interview Prep — [Company] — [Role]

One file per role. Every round for this role lives here: forecasted questions, polished answers, questions to ask them, risks and how to address them, coaching feedback, and anything you remember after the real interview. Do not create separate files per round. Copy this template into `05_INTERVIEW/role_specific/company_role/interview_prep.md` when you start prepping a new role (the `/3-interview` command does this for you).

## How To Use This File

Work through each section in order of priority:

- **Section A (Opening)** — must be automatic before any interview
- **Section B (Role-specific)** — the highest-probability questions for this exact JD
- **Section C (Behavioural)** — standard competency questions
- **Section D (Technical / domain)** — where the gap risk is highest
- **Section E (Company / mission)** — needed but lower risk
- **Section F (Closing)** — questions to ask them

Practise out loud. Written prep is not sufficient.

## Role Context

- Company:
- Role:
- Job description link:
- What matters to them (mission, product, signals from the JD):
- Salary context:

## Interviewers

- Round 1:
- Round 2:
- Later rounds:

---

## Round 1 — [type, date]

### Forecasted questions (work through in priority order)

**A. Opening** — automatic before any interview (tell me about yourself, why this role, why now)
-

**B. Role-specific** — highest-probability questions for this exact JD
-

**C. Behavioural** — standard competency questions
-

**D. Technical / domain** — where gap risk is highest
-

**E. Company / mission** — needed but lower risk
-

**F. Questions to ask them** — always prepared for this stage, tailored to the interviewer and where you are in the process
-

### Polished answers

**Q:**
**A:**

### Risks and how to address them

Likely follow-ups and weak spots for this role, and the plan for each.

- Risk:
  - How to address:

### Coaching feedback

- What worked:
- What to improve:
- Practical next steps:

### Remembered from the actual interview

Questions they actually asked, your read on how it went, any feedback received. Capture this right after, while it is fresh (or run `/capture-learning`).

-

---

## Round 2 — [type, date]

<!-- Same structure (Sections A to F, polished answers, risks, coaching, remembered). Add rounds as they come. -->
