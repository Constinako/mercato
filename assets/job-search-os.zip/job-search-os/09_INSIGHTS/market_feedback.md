# Market Feedback

Signals coming back from the market: recruiter comments, rejection reasons, what gets a response and what gets silence. This is the evidence base behind your candidate-market fit hypotheses in `01_PROFILE/candidate_market_fit.md`.

## Response Signals

- Where you are getting traction:
- Where you are getting silence or early rejection:

## Recurring Objections

Doubts or gaps that come up more than once.

-

## Compensation Signals

What the market seems to offer for your target roles.

-

## Open Hypotheses to Watch

-
