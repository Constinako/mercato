# Recurring Patterns

Patterns that repeat across your search: questions that keep coming up, stories that keep landing, mistakes that keep recurring, role types that keep converting or stalling. The system adds to this as evidence accumulates through `/capture-learning`.

## Questions That Keep Coming Up

-

## Stories That Land

-

## Stories That Fall Flat

-

## Role Types: Convert vs Stall

- Convert:
- Stall:

## Mistakes to Stop Repeating

-
