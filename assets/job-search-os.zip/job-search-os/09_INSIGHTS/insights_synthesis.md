# Insights Synthesis

This is the distilled, dashboard-facing summary of what your search is telling you. The dashboard reads the three sections below and renders them in the qualitative half of `/4-dashboard`. Keep it general (not per-role) and short. Refresh it when you run `/4-dashboard` or `/report`, drawing on the tracker and the rest of `09_INSIGHTS/`.

Section headers below must stay exactly as written, or the dashboard cannot find them.

## Candidate-Market Fit Hypothesis

<!-- One short paragraph: who the market should see you as and what you are betting converts. Sharpens over time. Use **bold** for emphasis. -->

## Tracks & Skills

<!-- Bullet list. Where to aim now, the adjacent track to grow into, and the gap-closing skills in priority order. Start each line with "- ". -->

## Insights

<!-- Bullet list of hand-curated patterns from interviews, rejections, and captured learnings. Start each line with "- ". -->
