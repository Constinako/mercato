# Learning Log

A running, dated log of what you learn as you go: interview takeaways, feedback received, what worked, what did not. The system appends here whenever you run `/capture-learning` or share how something went.

Newest entries at the top.

<!--
## YYYY-MM-DD — [Company / Role / Event]
- What happened:
- What worked:
- What to improve:
- Next focus:
-->
